#!/usr/bin/env python3
"""한글 문서(HWP 5.0 / HWPX) -> Markdown 추출기.

외부 패키지 없이 Python 표준 라이브러리만 사용한다.
  - 본문(Markdown)은 stdout 또는 -o 파일로 출력
  - 점검 보고와 최종 판정은 stderr로 출력

원칙: 문서를 빠짐없이 읽었다고 확인할 수 없으면 '불완전 추출'로 판정한다.

종료 코드: 0 완전 추출 / 4 불완전 추출(결과는 생성됨) / 2·3 실패

사용법:
  python3 read_hwp.py 문서.hwp  [-o 결과.md]
  python3 read_hwp.py 문서.hwpx [-o 결과.md]
"""
import argparse
import re
import struct
import sys
import zipfile
import zlib
import xml.etree.ElementTree as ET

MAX_XML_BYTES = 300 * 1024 * 1024      # HWPX 구역 하나의 최대 해제 크기
MAX_STREAM_BYTES = 300 * 1024 * 1024   # HWP 구역 하나의 최대 해제 크기
MAX_TABLE_CELLS = 200_000              # 표 하나의 최대 칸 수(행×열)


class ReadError(Exception):
    pass


def norm(s):
    return re.sub(r'\s+', '', s)


class Stats:
    def __init__(self):
        self.table_no = 0
        self.table_stack = []
        self.nested = []
        self.images = 0
        self.notes = []          # 참고 사항
        self.incomplete = []     # 불완전 판정 사유
        self.raw_chars = 0       # 원문 구조에 들어 있는 글자 수
        self.out_chars = 0       # 실제로 추출한 글자 수
        self.raw_paras = 0
        self.out_paras = 0


# ============================================================ 표 (공통)

def table_markdown(cells, st, num):
    """cells: [(row, col, rowspan, colspan, text)].

    실제 셀이 시작하는 행·열은 모두 보존한다(빈 셀 포함).
    병합으로만 생기는 칸은 빈 칸으로 표시한다.
    """
    if not cells:
        return ''
    origin = {}
    for r, c, rs, cs, t in cells:
        origin[(r, c)] = t
    h = max(r + max(rs, 1) for r, c, rs, cs, _ in cells)
    w = max(c + max(cs, 1) for r, c, rs, cs, _ in cells)
    if h * w > MAX_TABLE_CELLS:
        st.incomplete.append(f'표 {num}이 너무 커서({h}×{w}) 내용을 추출하지 않았습니다.')
        return '(표가 너무 커서 생략됨)'
    rows = sorted({r for r, _ in origin})
    cols = sorted({c for _, c in origin})
    esc = lambda s: s.strip().replace('|', '\\|').replace('\n', '<br>')
    lines = []
    for i, r in enumerate(rows):
        lines.append('| ' + ' | '.join(esc(origin.get((r, c), '')) for c in cols) + ' |')
        if i == 0:
            lines.append('|' + '---|' * len(cols))
    return '\n'.join(lines)


def table_begin(st):
    st.table_no += 1
    num = st.table_no
    parent = st.table_stack[-1] if st.table_stack else None
    st.table_stack.append(num)
    return num, parent


def table_end(st, num, parent, cells, caption=''):
    st.table_stack.pop()
    md = table_markdown(cells, st, num)
    label = f'[표 {num}]'
    if parent:
        label += f' (표 {parent}의 셀 안)'
    if caption:
        label += ' ' + caption
    block = label + '\n' + md if md else label + ' (빈 표)'
    if parent:                       # 중첩 표는 바깥 표 뒤에 따로 출력
        st.nested.append((num, block))
        return [f'[표 {num} 참조]']
    out = [block] + [b for _, b in sorted(st.nested)]
    st.nested.clear()
    return out


# ============================================================ HWPX (ZIP + XML)

def local(tag):
    return tag.rsplit('}', 1)[-1]


def hwpx_t(t):
    parts = [t.text or '']
    for c in t:
        n = local(c.tag)
        if n == 'tab':
            parts.append('\t')
        elif n == 'lineBreak':
            parts.append('\n')
        elif n in ('fwSpace', 'nbSpace'):
            parts.append(' ')
        elif n == 'hyphen':
            parts.append('-')
        parts.append(c.tail or '')
    return ''.join(parts)


def hwpx_sublists(elem):
    """elem 아래의 subList를 찾되, 찾은 subList 내부로는 더 내려가지 않는다."""
    for c in elem:
        if local(c.tag) == 'subList':
            yield c
        else:
            yield from hwpx_sublists(c)


def hwpx_table(tbl, st):
    num, parent = table_begin(st)
    cells = []
    caption = []
    for tr in tbl:
        tn = local(tr.tag)
        if tn != 'tr':
            for sub in hwpx_sublists(tr):
                for sp in sub:
                    if local(sp.tag) == 'p':
                        caption += hwpx_para(sp, st)
            continue
        for tc in tr:
            if local(tc.tag) != 'tc':
                continue
            r = c0 = 0
            rs = cs = 1
            texts = []
            for c in tc:
                n = local(c.tag)
                if n == 'cellAddr':
                    r, c0 = int(c.get('rowAddr', 0)), int(c.get('colAddr', 0))
                elif n == 'cellSpan':
                    rs, cs = int(c.get('rowSpan', 1)), int(c.get('colSpan', 1))
                elif n == 'subList':
                    for p in c:
                        if local(p.tag) == 'p':
                            texts += hwpx_para(p, st)
            cells.append((r, c0, rs, cs, '\n'.join(t for t in texts if t.strip())))
    return table_end(st, num, parent, cells, ' '.join(t for t in caption if t.strip()))


HWPX_LABEL = {'header': '[머리말] ', 'footer': '[꼬리말] ',
              'footNote': '[각주] ', 'endNote': '[미주] '}


def hwpx_para(p, st):
    st.out_paras += 1
    blocks, buf = [], []

    def flush():
        s = ''.join(buf).strip()
        if s:
            blocks.append(s)
        buf.clear()

    for run in p:
        if local(run.tag) != 'run':
            continue
        for c in run:
            n = local(c.tag)
            if n == 't':
                s = hwpx_t(c)
                st.out_chars += len(norm(s))
                buf.append(s)
            elif n == 'tbl':
                flush()
                blocks += hwpx_table(c, st)
            else:
                if n == 'pic':
                    st.images += 1
                subs = list(hwpx_sublists(c))
                if subs:
                    flush()
                    prefix = HWPX_LABEL.get(n, '')
                    for k, v in HWPX_LABEL.items():
                        if not prefix and c.find('.//{*}' + k) is not None:
                            prefix = v
                    for sub in subs:
                        for sp in sub:
                            if local(sp.tag) == 'p':
                                for b in hwpx_para(sp, st):
                                    blocks.append(prefix + b if prefix else b)
    flush()
    return blocks


def decode_preview(raw):
    if raw.startswith(b'\xef\xbb\xbf'):
        return raw[3:].decode('utf-8', 'replace')
    if raw.startswith(b'\xff\xfe'):
        return raw[2:].decode('utf-16-le', 'replace')
    if raw and raw.count(b'\x00') >= len(raw) // 4:   # NUL이 많으면 UTF-16LE
        return raw.decode('utf-16-le', 'ignore')
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError as e:
        if e.start >= len(raw) - 3:                    # 끝 글자만 잘린 경우
            return raw[:e.start].decode('utf-8')
    try:
        return raw.decode('cp949')
    except UnicodeDecodeError:
        return raw.decode('utf-8', 'ignore')


def read_hwpx(path, st):
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise ReadError('HWPX(ZIP) 구조가 손상되었습니다.')
    names = z.namelist()
    secs = sorted((n for n in names if re.match(r'Contents/section\d+\.xml$', n)),
                  key=lambda n: int(re.findall(r'\d+', n)[-1]))
    if not secs:
        raise ReadError('본문(section*.xml)이 없습니다. 암호가 걸렸거나 HWPX가 아닐 수 있습니다.')
    sec_blocks = []
    for s in secs:
        if z.getinfo(s).file_size > MAX_XML_BYTES:
            st.incomplete.append(f'{s}가 너무 커서 읽지 않았습니다.')
            sec_blocks.append([])
            continue
        try:
            root = ET.fromstring(z.read(s))
        except (ET.ParseError, zipfile.BadZipFile, zlib.error, EOFError) as e:
            st.incomplete.append(f'{s} 손상 — 이 구역을 읽지 못했습니다({type(e).__name__}).')
            sec_blocks.append([])
            continue
        for t in root.iter():
            n = local(t.tag)
            if n == 't':
                st.raw_chars += len(norm(hwpx_t(t)))
            elif n == 'p':
                st.raw_paras += 1
        blocks = []
        for p in root:
            if local(p.tag) == 'p':
                blocks += hwpx_para(p, st)
        sec_blocks.append(blocks)
    st.images = max(st.images, sum(1 for n in names if n.startswith('BinData/')))
    preview = ''
    if 'Preview/PrvText.txt' in names:
        preview = decode_preview(z.read('Preview/PrvText.txt'))
    return sec_blocks, preview


# ============================================================ HWP 5.0 (OLE 복합 문서)

END = 0xFFFFFFFA


class OLE:
    """최소한의 OLE(Compound File Binary) 읽기 구현."""

    def __init__(self, data):
        if data[:8] != b'\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1':
            raise ReadError('OLE 형식이 아닙니다.')
        self.d = data
        self.broken = []
        self.ss = 1 << struct.unpack_from('<H', data, 0x1E)[0]
        self.mss = 1 << struct.unpack_from('<H', data, 0x20)[0]
        nfat = struct.unpack_from('<I', data, 0x2C)[0]
        dir_start = struct.unpack_from('<I', data, 0x30)[0]
        self.cutoff = struct.unpack_from('<I', data, 0x38)[0]
        mf_start, n_mf, difat_start, n_difat = struct.unpack_from('<IIII', data, 0x3C)

        difat = list(struct.unpack_from('<109I', data, 0x4C))
        per = self.ss // 4 - 1
        s, seen = difat_start, set()
        for _ in range(n_difat):
            if s >= END or s in seen:
                break
            seen.add(s)
            sec = self._sector(s)
            if len(sec) < self.ss:
                raise ReadError('파일이 잘려 있습니다(DIFAT).')
            vals = struct.unpack_from('<%dI' % (per + 1), sec)
            difat.extend(vals[:per])
            s = vals[per]
        self.fat = []
        for s in difat[:nfat]:
            if s < END:
                sec = self._sector(s)
                if len(sec) < self.ss:
                    raise ReadError('파일이 잘려 있습니다(FAT).')
                self.fat.extend(struct.unpack_from('<%dI' % (self.ss // 4), sec))

        dirdata = self._chain(dir_start)
        self.entries = []
        for off in range(0, len(dirdata) - 127, 128):
            e = dirdata[off:off + 128]
            nl = struct.unpack_from('<H', e, 0x40)[0]
            name = e[:max(min(nl, 64) - 2, 0)].decode('utf-16-le', 'replace')
            left, right, child = struct.unpack_from('<III', e, 0x44)
            start = struct.unpack_from('<I', e, 0x74)[0]
            size = struct.unpack_from('<Q', e, 0x78)[0]
            if self.ss == 512:
                size &= 0xFFFFFFFF
            self.entries.append(dict(name=name, type=e[0x42], left=left,
                                     right=right, child=child, start=start, size=size))
        if not self.entries:
            raise ReadError('OLE 디렉터리를 읽을 수 없습니다.')
        root = self.entries[0]
        self.ministream = self._chain(root['start'])[:root['size']] if root['start'] < END else b''
        self.minifat = []
        if n_mf and mf_start < END:
            mf = self._chain(mf_start)
            self.minifat = list(struct.unpack_from('<%dI' % (len(mf) // 4), mf))
        self.streams = {}
        self._walk(root['child'], '', set())

    def _sector(self, s):
        off = (s + 1) * self.ss
        return self.d[off:off + self.ss]

    def _chain(self, s):
        out, seen = [], set()
        while s < END and s not in seen and s < len(self.fat):
            seen.add(s)
            out.append(self._sector(s))
            s = self.fat[s]
        return b''.join(out)

    def _minichain(self, s):
        out, seen = [], set()
        while s < END and s not in seen and s < len(self.minifat):
            seen.add(s)
            off = s * self.mss
            out.append(self.ministream[off:off + self.mss])
            s = self.minifat[s]
        return b''.join(out)

    def _walk(self, i, prefix, seen):
        stack = [i]
        while stack:
            i = stack.pop()
            if i >= END or i >= len(self.entries) or i in seen:
                continue
            seen.add(i)
            e = self.entries[i]
            stack += [e['left'], e['right']]
            p = prefix + e['name']
            if e['type'] == 1:
                self._walk(e['child'], p + '/', seen)
            elif e['type'] == 2:
                self.streams[p] = e

    def read(self, path):
        """스트림을 읽는다. 선언된 크기보다 짧으면 (데이터, False)."""
        e = self.streams[path]
        if e['size'] < self.cutoff:
            data = self._minichain(e['start'])
        else:
            data = self._chain(e['start'])
        return data[:e['size']], len(data) >= e['size']


TAG_PARA_HEADER, TAG_PARA_TEXT, TAG_CTRL_HEADER, TAG_LIST_HEADER, TAG_TABLE = 66, 67, 71, 72, 77
TAG_SHAPE_PICTURE = 85
CH_EXT = {1, 2, 3, 11, 12, 14, 15, 16, 17, 18, 21, 22, 23}   # 확장 컨트롤(8 WCHAR)
CH_INL = {4, 5, 6, 7, 8, 9, 19, 20}                         # 인라인 컨트롤(8 WCHAR)


def hwp_records(data):
    """레코드 목록과 손상 여부(선언 길이보다 데이터가 짧음)를 돌려준다."""
    recs, i, n = [], 0, len(data)
    while i < n:
        if i + 4 > n:
            return recs, True
        h = struct.unpack_from('<I', data, i)[0]
        i += 4
        tag, lvl, size = h & 0x3FF, (h >> 10) & 0x3FF, (h >> 20) & 0xFFF
        if size == 0xFFF:
            if i + 4 > n:
                return recs, True
            size = struct.unpack_from('<I', data, i)[0]
            i += 4
        if i + size > n:
            return recs, True            # 잘린 레코드는 버리고 손상으로 판정
        recs.append([tag, lvl, data[i:i + size], []])
        i += size
    return recs, False


def hwp_tree(recs):
    root = [-1, -1, b'', []]
    stack = [root]
    for r in recs:
        while len(stack) > 1 and stack[-1][1] >= r[1]:
            stack.pop()
        stack[-1][3].append(r)
        stack.append(r)
    return root


def hwp_para_segments(b):
    """PARA_TEXT -> [텍스트, None(컨트롤 자리), 텍스트, ...]"""
    u = struct.unpack('<%dH' % (len(b) // 2), b[:len(b) // 2 * 2])
    segs, buf, i = [], [], 0

    def take():
        segs.append(struct.pack('<%dH' % len(buf), *buf).decode('utf-16-le', 'replace'))
        buf.clear()

    while i < len(u):
        c = u[i]
        if c < 32:
            if c in CH_EXT or c in CH_INL:
                if c == 9:
                    buf.append(9)
                if c in CH_EXT:
                    take()
                    segs.append(None)
                i += 8
                continue
            if c == 10:
                buf.append(10)
            elif c == 24:
                buf.append(ord('-'))
            elif c in (30, 31):
                buf.append(32)
            i += 1
            continue
        buf.append(c)
        i += 1
    take()
    return segs


def ctrl_id(rec):
    return rec[2][:4][::-1].decode('latin1', 'replace') if len(rec[2]) >= 4 else ''


def hwp_children(children, st):
    blocks = []
    for ch in children:
        if ch[0] == TAG_PARA_HEADER:
            blocks += hwp_para(ch, st)
        elif ch[0] == TAG_CTRL_HEADER:
            blocks += hwp_ctrl(ch, st)
        else:
            if ch[0] == TAG_SHAPE_PICTURE:
                st.images += 1
            blocks += hwp_children(ch[3], st)
    return blocks


def hwp_para(node, st):
    st.out_paras += 1
    text_rec = next((c for c in node[3] if c[0] == TAG_PARA_TEXT), None)
    ctrls = [c for c in node[3] if c[0] == TAG_CTRL_HEADER]
    segs = hwp_para_segments(text_rec[2]) if text_rec else ['']
    st.out_chars += sum(len(norm(s)) for s in segs if s)
    blocks, buf, ci = [], [], 0

    def flush():
        s = ''.join(buf).strip()
        if s:
            blocks.append(s)
        buf.clear()

    for s in segs:
        if s is None:
            if ci < len(ctrls):
                out = hwp_ctrl(ctrls[ci], st)
                ci += 1
                if out:
                    flush()
                    blocks += out
        else:
            buf.append(s)
    flush()
    for c in ctrls[ci:]:
        blocks += hwp_ctrl(c, st)
    # 문단 아래에 예상 밖 위치로 붙은 하위 레코드도 놓치지 않는다
    for c in node[3]:
        if c[0] not in (TAG_PARA_TEXT, TAG_CTRL_HEADER) and c[3]:
            blocks += hwp_children(c[3], st)
    return blocks


def hwp_table(ctrl, st):
    num, parent = table_begin(st)
    nrows = ncols = 0
    caption, raw_cells, cur, seen_table = [], [], None, False
    for ch in ctrl[3]:
        if ch[0] == TAG_TABLE:
            seen_table = True
            if len(ch[2]) >= 8:
                nrows, ncols = struct.unpack_from('<HH', ch[2], 4)
        elif ch[0] == TAG_LIST_HEADER:
            if not seen_table:          # 표 앞의 LIST_HEADER는 캡션
                cur = None
                caption += hwp_children(ch[3], st)
                continue
            cur = [ch[2], hwp_children(ch[3], st)]
            raw_cells.append(cur)
        elif ch[0] == TAG_PARA_HEADER:
            if cur is not None:
                cur[1] += hwp_para(ch, st)
            else:
                caption += hwp_para(ch, st)
        else:
            extra = hwp_children(ch[3], st)
            if extra:
                (cur[1] if cur is not None else caption).extend(extra)

    def layout(off):
        out, used = [], set()
        for b, texts in raw_cells:
            if len(b) < off + 8:
                return None
            col, row, cs, rs = struct.unpack_from('<4H', b, off)
            if (ncols and col >= ncols) or (nrows and row >= nrows) or cs == 0 or rs == 0 \
                    or (row, col) in used:
                return None
            used.add((row, col))
            out.append((row, col, rs, cs, '\n'.join(texts)))
        return out

    cells = layout(8) or layout(6)
    if cells is None:                   # 주소를 해석하지 못하면 순서대로 채움
        st.incomplete.append(f'표 {num}의 셀 위치를 해석하지 못해 순서대로 배치했습니다(배치 부정확 가능).')
        w = ncols or 1
        cells = [(i // w, i % w, 1, 1, '\n'.join(t)) for i, (_, t) in enumerate(raw_cells)]
    elif nrows and ncols and not any(r == nrows - 1 or r + rs == nrows for r, _, rs, _, _ in cells):
        st.notes.append(f'표 {num}: 선언된 행 수({nrows})와 실제 셀 배치가 다릅니다.')
    return table_end(st, num, parent, cells, ' '.join(caption))


def hwp_ctrl(ctrl, st):
    cid = ctrl_id(ctrl)
    if cid == 'tbl ':
        return hwp_table(ctrl, st)
    blocks = hwp_children(ctrl[3], st)
    prefix = {'head': '[머리말] ', 'foot': '[꼬리말] ', 'fn  ': '[각주] ', 'en  ': '[미주] '}.get(cid)
    if prefix:
        blocks = [prefix + b for b in blocks]
    return blocks


def inflate(data, limit):
    d = zlib.decompressobj(-15)
    out = d.decompress(data, limit)
    if d.unconsumed_tail:
        raise ReadError('해제 크기 제한 초과')
    if not d.eof:
        raise zlib.error('압축 데이터가 끝나지 않음(잘림)')
    return out + d.flush()


def read_hwp(path, st):
    with open(path, 'rb') as f:
        ole = OLE(f.read())
    if 'FileHeader' not in ole.streams:
        raise ReadError('FileHeader가 없습니다. HWP 5.0 문서가 아닙니다(HWP 3.0 이하는 지원하지 않음).')
    fh, _ = ole.read('FileHeader')
    if not fh.startswith(b'HWP Document File') or len(fh) < 40:
        raise ReadError('HWP 서명이 올바르지 않습니다.')
    props = struct.unpack_from('<I', fh, 36)[0]
    compressed, encrypted, distrib = props & 1, props & 2, props & 4

    preview = ''
    if 'PrvText' in ole.streams:
        preview = ole.read('PrvText')[0].decode('utf-16-le', 'ignore')
    st.images = sum(1 for n in ole.streams if n.startswith('BinData/'))

    if encrypted:
        raise ReadError('암호가 걸린 문서입니다. 한글에서 암호를 해제한 뒤 다시 올려 주세요.')
    if distrib:
        st.incomplete.append('배포용(열람 전용) 문서라 본문이 암호화되어 있습니다. 미리보기(앞부분)만 제공합니다.')
        return [[preview.strip()]] if preview.strip() else [[]], preview

    secs = sorted((n for n in ole.streams if re.match(r'BodyText/Section\d+$', n)),
                  key=lambda n: int(re.findall(r'\d+', n)[-1]))
    if not secs:
        raise ReadError('본문(BodyText)이 없습니다.')
    nums = [int(re.findall(r'\d+', n)[-1]) for n in secs]
    if nums != list(range(len(nums))):
        st.incomplete.append(f'구역 번호가 연속되지 않습니다({nums}) — 구역 누락 가능.')
    sec_blocks = []
    for s in secs:
        data, whole = ole.read(s)
        if not whole:
            st.incomplete.append(f'{s} 스트림이 잘려 있습니다(파일 손상).')
        if compressed:
            try:
                data = inflate(data, MAX_STREAM_BYTES)
            except ReadError:
                st.incomplete.append(f'{s}가 너무 커서 읽지 않았습니다.')
                sec_blocks.append([])
                continue
            except zlib.error:
                st.incomplete.append(f'{s} 압축 해제 실패 — 이 구역 내용이 결과에 없습니다.')
                sec_blocks.append([])
                continue
        recs, broken = hwp_records(data)
        if broken:
            st.incomplete.append(f'{s} 레코드가 중간에 잘려 있습니다 — 뒷부분 내용이 빠졌을 수 있습니다.')
        st.raw_paras += sum(1 for r in recs if r[0] == TAG_PARA_HEADER)
        for r in recs:
            if r[0] == TAG_PARA_TEXT:
                st.raw_chars += sum(len(norm(x)) for x in hwp_para_segments(r[2]) if x)
        sec_blocks.append(hwp_children(hwp_tree(recs)[3], st))
    return sec_blocks, preview


# ============================================================ 점검·판정

# 반각 가타카나·반각 한글 자모는 깨짐 의심. 반각 문장부호 ｡｢｣､･(U+FF61~FF65)는
# 공문서에서 정상적으로 쓰이므로 제외한다.
SUSPECT = re.compile(r'[\uFFFD\uE000-\uF8FF\uFF66-\uFFDC\x00-\x08\x0B\x0C\x0E-\x1F]')


def check(text, preview, st, fmt, nsec):
    lines = [f'[점검] 형식: {fmt} / 구역 {nsec}개 / 문단 {st.out_paras}개 / 표 {st.table_no}개'
             + (f' / 이미지 {st.images}개(내용은 읽지 않음)' if st.images else '')]

    # 1) 전체 텍스트 대조: 원문 구조 안의 글자 수 vs 실제 추출 글자 수
    if st.raw_chars or st.out_chars:
        lines.append(f'[점검] 전체 글자 대조: 원문 {st.raw_chars:,}자 / 추출 {st.out_chars:,}자')
        if st.out_chars < st.raw_chars:
            st.incomplete.append(f'원문 텍스트 {st.raw_chars - st.out_chars:,}자가 추출 결과에 없습니다.')
        elif st.out_chars > st.raw_chars:
            st.notes.append('추출 글자가 원문보다 많습니다 — 중복 추출 가능성이 있습니다.')
    if st.raw_paras and st.out_paras < st.raw_paras:
        st.notes.append(f'문단 {st.raw_paras - st.out_paras}개를 방문하지 못했습니다(글자 대조가 일치하면 빈 문단).')

    # 2) 깨짐 의심 문자
    hits = [(m.start(), m.group()) for m in SUSPECT.finditer(text)]
    if hits:
        samples = []
        for pos, ch in hits[:8]:
            ctx = text[max(0, pos - 12):pos + 12].replace('\n', ' ')
            samples.append(f'U+{ord(ch):04X} "…{ctx}…"')
        lines.append(f'[점검] 깨짐 의심 문자 {len(hits)}개: ' + ' | '.join(samples))
    else:
        lines.append('[점검] 깨짐 의심 문자: 없음')

    # 3) 미리보기(한글이 저장한 앞부분 텍스트)와 독립 대조
    if preview.strip():
        body = norm(re.sub(r'<br>|\\\||\||---|\[표 \d+[^\]]*\]', '', text))
        chunks = [norm(c) for c in re.split(r'[<>\r\n]+', preview)]
        chunks = [c for c in chunks if len(c) >= 4]
        if chunks and len(preview) >= 1000:
            chunks = chunks[:-1]          # 미리보기 끝은 잘려 있을 수 있음
        if chunks:
            missing = [c for c in chunks if c not in body]
            cov = 100 * (len(chunks) - len(missing)) / len(chunks)
            msg = f'[점검] 미리보기(문서 앞부분만) 대조: {cov:.0f}% 일치'
            if missing:
                msg += ' — 누락 의심: ' + ' | '.join(m[:30] for m in missing[:5])
                st.incomplete.append('미리보기에 있는 문장이 추출 결과에 없습니다.')
            lines.append(msg)
    else:
        lines.append('[점검] 미리보기 텍스트 없음 — 앞부분 대조 생략')

    for n in st.notes:
        lines.append('[참고] ' + n)
    if st.incomplete:
        lines.append('[판정] 불완전 추출 — 아래 사유로 원문 일부가 빠졌거나 부정확할 수 있습니다.')
        lines += ['  - ' + r for r in dict.fromkeys(st.incomplete)]
    else:
        lines.append('[판정] 완전 추출 — 원문 구조의 모든 텍스트를 추출했습니다'
                     + ('(이미지 속 글자 제외).' if st.images else '.'))
    return '\n'.join(lines)


def detect(path):
    with open(path, 'rb') as f:
        head = f.read(32)
    if head[:2] == b'PK':
        return 'HWPX'
    if head[:8] == b'\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1':
        return 'HWP'
    if head.startswith(b'HWP Docu'):
        raise ReadError('HWP 3.0 이하 구형 문서는 지원하지 않습니다. 한글에서 다른 이름으로 저장(HWP/HWPX) 후 올려 주세요.')
    raise ReadError('HWP/HWPX 파일이 아닙니다.')


def extract(path):
    """(markdown, 보고문, 완전여부) — 테스트에서도 사용."""
    st = Stats()
    fmt = detect(path)
    sec_blocks, preview = (read_hwpx if fmt == 'HWPX' else read_hwp)(path, st)
    parts = []
    for i, blocks in enumerate(sec_blocks, 1):
        if len(sec_blocks) > 1:
            parts.append(f'〔구역 {i}〕')
        parts += [b for b in blocks if b.strip()]
    text = '\n\n'.join(parts) + '\n'
    report = check(text, preview, st, fmt, len(sec_blocks))
    return text, report, not st.incomplete


def main():
    ap = argparse.ArgumentParser(description='HWP/HWPX -> Markdown')
    ap.add_argument('file')
    ap.add_argument('-o', '--output')
    a = ap.parse_args()
    try:
        text, report, complete = extract(a.file)
    except ReadError as e:
        print(f'[실패] {e}', file=sys.stderr)
        sys.exit(2)
    except Exception as e:  # 손상 파일 등
        print(f'[실패] 문서를 해석하지 못했습니다: {type(e).__name__}: {e}', file=sys.stderr)
        sys.exit(3)
    if a.output:
        with open(a.output, 'w', encoding='utf-8') as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    print(report, file=sys.stderr)
    sys.exit(0 if complete else 4)


if __name__ == '__main__':
    main()
