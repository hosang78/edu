#!/usr/bin/env python3
"""hwp-reader 회귀 테스트 (표준 라이브러리만 사용).

합성 HWP·HWPX 파일을 만들어 추출 결과와 판정을 확인한다.
실제 문서를 추가로 확인하려면 경로를 인자로 준다:
  python3 run_tests.py [실제문서.hwp ...]
"""
import os
import json
import subprocess
import struct
import sys
import tempfile
import zipfile
import zlib

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
import read_hwp as R  # noqa: E402

# ------------------------------------------------------------ HWP 생성기

def rec(tag, lvl, data):
    if len(data) < 0xFFF:
        return struct.pack('<I', tag | (lvl << 10) | (len(data) << 20)) + data
    return struct.pack('<II', tag | (lvl << 10) | (0xFFF << 20), len(data)) + data


def u16(s):
    return s.encode('utf-16-le')


def ext(ch, cid):
    return struct.pack('<H', ch) + cid[::-1].encode('latin1') + b'\0' * 8 + struct.pack('<H', ch)


TAB = struct.pack('<H', 9) + b'\0' * 12 + struct.pack('<H', 9)
EOP = struct.pack('<H', 13)


def para(lvl, raw):
    return rec(66, lvl, b'\0' * 22) + rec(67, lvl + 1, raw)


def cell(lvl, col, row, cs, rs, text=None, inner=b''):
    lh = struct.pack('<HHI4H', 1, 0, 0, col, row, cs, rs) + b'\0' * 18
    if inner:
        return rec(72, lvl, lh) + inner
    return rec(72, lvl, lh) + para(lvl, u16(text) + EOP)


def table(lvl, nrows, ncols, cells_bytes, before='', after=''):
    out = rec(66, lvl, b'\0' * 22)
    out += rec(67, lvl + 1, u16(before) + ext(11, 'tbl ') + u16(after) + EOP)
    out += rec(71, lvl + 1, b' lbt' + b'\0' * 40)
    out += rec(77, lvl + 2, struct.pack('<IHH', 0, nrows, ncols) + b'\0' * 20)
    return out + cells_bytes


def ole(streams):
    """streams: {'FileHeader': bytes, 'BodyText/Section0': bytes, ...} -> OLE 바이트."""
    SS, MSS = 512, 64
    ents = [('Root Entry', 5, None, None)]
    storages = {}
    for path, data in streams.items():
        parent = 0
        if '/' in path:
            sname, path = path.split('/', 1)
            if sname not in storages:
                ents.append((sname, 1, 0, None))
                storages[sname] = len(ents) - 1
            parent = storages[sname]
        ents.append((path, 2, parent, data))
    mini, minifat, regular, starts = b'', [], [], {}
    for i, (n, t, p, d) in enumerate(ents):
        if t == 2 and len(d) < 4096:
            nsec = max((len(d) + MSS - 1) // MSS, 1)
            s0 = len(mini) // MSS
            starts[i] = s0
            minifat += [s0 + k + 1 for k in range(nsec - 1)] + [0xFFFFFFFE]
            mini += d.ljust(nsec * MSS, b'\0')
        elif t == 2:
            regular.append(i)
    pad = lambda b: b.ljust(max((len(b) + SS - 1) // SS, 1) * SS, b'\0')
    mf = b''.join(struct.pack('<I', x) for x in minifat)
    mf = mf.ljust(max((len(mf) + SS - 1) // SS, 1) * SS, b'\xff')
    dir_len = ((len(ents) * 128 + SS - 1) // SS) * SS
    blobs = [['dir', b'\0' * dir_len], ['minifat', mf], ['mini', pad(mini)]]
    blobs += [[i, pad(ents[i][3])] for i in regular]
    nother = sum(len(b) // SS for _, b in blobs)
    nfat = 1
    while nfat * 128 < nother + nfat:
        nfat += 1
    fat, pos, loc = [0xFFFFFFFD] * nfat, nfat, {}
    for key, b in blobs:
        n = len(b) // SS
        loc[key] = pos
        fat += [pos + k + 1 for k in range(n - 1)] + [0xFFFFFFFE]
        pos += n
    fat += [0xFFFFFFFF] * (nfat * 128 - len(fat))
    for i in regular:
        starts[i] = loc[i]
    kids = {}
    for i, (n, t, p, d) in enumerate(ents):
        if p is not None:
            kids.setdefault(p, []).append(i)
    right, first = {}, {}
    for p, cs in kids.items():
        first[p] = cs[0]
        for a, b in zip(cs, cs[1:]):
            right[a] = b

    def dirent(name, typ, child, rt, start, size):
        nb = u16(name) + b'\0\0'
        e = nb.ljust(64, b'\0') + struct.pack('<HBB', len(nb), typ, 1)
        e += struct.pack('<III', 0xFFFFFFFF, rt, child) + b'\0' * 36
        return (e + struct.pack('<IQ', start, size)).ljust(128, b'\0')

    dd = b''
    for i, (n, t, p, d) in enumerate(ents):
        nx = 0xFFFFFFFF
        if t == 5:
            dd += dirent(n, 5, first.get(i, nx), nx, loc['mini'], len(mini))
        elif t == 1:
            dd += dirent(n, 1, first.get(i, nx), right.get(i, nx), 0, 0)
        else:
            dd += dirent(n, 2, nx, right.get(i, nx), starts[i], len(d))
    blobs[0][1] = dd.ljust(dir_len, b'\0')
    hdr = b'\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1' + b'\0' * 16 + struct.pack('<HHHH', 0x3E, 3, 0xFFFE, 9)
    hdr += struct.pack('<H', 6) + b'\0' * 6 + struct.pack('<IIIII', 0, nfat, loc['dir'], 0, 4096)
    hdr += struct.pack('<IIII', loc['minifat'], len(mf) // SS, 0xFFFFFFFE, 0)
    hdr += struct.pack('<109I', *(list(range(nfat)) + [0xFFFFFFFF] * (109 - nfat)))
    return hdr + b''.join(struct.pack('<I', x) for x in fat) + b''.join(b for _, b in blobs)


def deflate(b):
    c = zlib.compressobj(9, zlib.DEFLATED, -15)
    return c.compress(b) + c.flush()


def hwp_file(body, props=1, preview='', section=None):
    fh = (b'HWP Document File'.ljust(32, b'\0') + struct.pack('<II', 0x05000300, props)).ljust(256, b'\0')
    s = {'FileHeader': fh, 'BodyText/Section0': section if section is not None
         else (deflate(body) if props & 1 else body)}
    if preview:
        s['PrvText'] = u16(preview)
    return ole(s)

# ------------------------------------------------------------ HWPX 생성기

NS = 'xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hs="http://www.hancom.co.kr/hwpml/2011/section"'


def xp(text):
    return f'<hp:p><hp:run><hp:t>{text}</hp:t></hp:run></hp:p>'


def xtc(r, c, inner, rs=1, cs=1):
    return (f'<hp:tc><hp:subList>{inner}</hp:subList><hp:cellAddr colAddr="{c}" rowAddr="{r}"/>'
            f'<hp:cellSpan colSpan="{cs}" rowSpan="{rs}"/></hp:tc>')


def xtbl(rows):
    return '<hp:tbl>' + ''.join('<hp:tr>' + ''.join(r) + '</hp:tr>' for r in rows) + '</hp:tbl>'


def xtable_p(rows):
    return f'<hp:p><hp:run>{xtbl(rows)}</hp:run></hp:p>'


def hwpx_file(body_xml, preview=None):
    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        z.writestr('mimetype', 'application/hwp+zip')
        z.writestr('Contents/section0.xml', f'<?xml version="1.0" encoding="UTF-8"?><hs:sec {NS}>{body_xml}</hs:sec>')
        if preview is not None:
            z.writestr('Preview/PrvText.txt', preview)
    return buf.getvalue()

# ------------------------------------------------------------ 테스트

TMP = tempfile.mkdtemp()


def run(name, data, ext):
    p = os.path.join(TMP, name + ext)
    with open(p, 'wb') as f:
        f.write(data)
    return R.extract(p)


results = []


def case(title, ok, detail=''):
    results.append(ok)
    print(('PASS ' if ok else 'FAIL ') + title + ('' if ok else f'\n     {detail}'))


# 1. 정상 HWP: 병합 셀, 탭, 이모지, 머리말, 일반·미니 섹터
body = para(0, u16('1. 관련근거') + EOP) + para(0, u16('□ 이름') + TAB + u16('값 😀') + EOP)
body += table(0, 2, 2, cell(2, 0, 0, 2, 1, '병합 제목') + cell(2, 0, 1, 1, 1, '왼쪽|칸')
              + cell(2, 1, 1, 1, 1, '오른쪽'), '표 앞', '표 뒤')
body += rec(66, 0, b'\0' * 22) + rec(67, 1, ext(16, 'head') + EOP) + rec(71, 1, b'daeh' + b'\0' * 8)
body += rec(72, 2, b'\0' * 12) + para(2, u16('머리말 문구') + EOP)
body += b''.join(para(0, u16(f'반복 문단 {i} 가나다라') + EOP) for i in range(400))
t, rep, ok = run('normal', hwp_file(body, preview='<>1. 관련근거\r\n□ 이름\t값\r\n'), '.hwp')
case('정상 HWP 완전 추출', ok and '값 😀' in t and '[머리말] 머리말 문구' in t
     and '| 왼쪽\\|칸 | 오른쪽 |' in t and t.index('표 앞') < t.index('[표 1]') < t.index('표 뒤'), rep)

# 2. 빈 행·빈 열 보존
body = table(0, 3, 3, cell(2, 0, 0, 1, 1, '구분') + cell(2, 1, 0, 1, 1, '승인 상태') + cell(2, 2, 0, 1, 1, '')
             + cell(2, 0, 1, 1, 1, '신청') + cell(2, 1, 1, 1, 1, '완료') + cell(2, 2, 1, 1, 1, '')
             + cell(2, 0, 2, 1, 1, '') + cell(2, 1, 2, 1, 1, '') + cell(2, 2, 2, 1, 1, ''))
t, rep, ok = run('empty_rows', hwp_file(body), '.hwp')
case('빈 행·열 보존 (HWP)', '|  |  |  |' in t and '| 구분 | 승인 상태 |  |' in t, t)
x = xtable_p([[xtc(0, 0, xp('구분')), xtc(0, 1, xp('승인 상태'))],
              [xtc(1, 0, xp('신청')), xtc(1, 1, xp('완료'))],
              [xtc(2, 0, '<hp:p/>'), xtc(2, 1, '<hp:p/>')]])
t, rep, ok = run('empty_rows', hwpx_file(x), '.hwpx')
case('빈 행 보존 (HWPX)', t.count('\n|  |  |') == 1 and ok, t)

# 3. 병합으로만 생긴 칸은 행·열을 늘리지 않음
x = xtable_p([[xtc(0, 0, xp('A'), cs=2)], [xtc(1, 0, xp('B')), xtc(1, 1, xp('C'))]])
t, rep, ok = run('merge', hwpx_file(x), '.hwpx')
case('병합 셀 배치', '| A |  |' in t and '| B | C |' in t, t)

# 4. 중첩 표는 바깥 표 뒤에 별도 표로
inner = xtbl([[xtc(0, 0, xp('내부1')), xtc(0, 1, xp('내부2'))]])
x = xtable_p([[xtc(0, 0, xp('바깥')), xtc(0, 1, f'<hp:p><hp:run>{inner}</hp:run></hp:p>')]])
t, rep, ok = run('nested', hwpx_file(x), '.hwpx')
case('중첩 표 분리·참조', '[표 2 참조]' in t and '[표 2] (표 1의 셀 안)' in t and '| 내부1 | 내부2 |' in t
     and t.index('[표 1]') < t.index('[표 2] (표 1'), t)
inner_h = table(2, 1, 2, cell(4, 0, 0, 1, 1, '내부1') + cell(4, 1, 0, 1, 1, '내부2'))
body = table(0, 1, 2, cell(2, 0, 0, 1, 1, '바깥') + cell(2, 1, 0, 1, 1, inner=inner_h))
t, rep, ok = run('nested', hwp_file(body), '.hwp')
case('중첩 표 분리·참조 (HWP)', '[표 2 참조]' in t and '| 내부1 | 내부2 |' in t and ok, t + rep)

# 5. 잘린 레코드 -> 불완전
body = para(0, u16('첫 문단') + EOP) + para(0, u16('둘째 문단 내용이 깁니다') + EOP)
t, rep, ok = run('trunc', hwp_file(body[:-6]), '.hwp')
case('잘린 레코드 불완전 판정', not ok and '잘려' in rep and '첫 문단' in t, rep)

# 6. 압축 해제 실패 -> 불완전
t, rep, ok = run('badzip', hwp_file(b'', section=b'\x00garbage-not-deflate'), '.hwp')
case('압축 해제 실패 불완전 판정', not ok and '압축 해제 실패' in rep, rep)
good = deflate(para(0, u16('내용') * 50 + EOP))
t, rep, ok = run('cutzip', hwp_file(b'', section=good[:len(good) // 2]), '.hwp')
case('압축 데이터 잘림 불완전 판정', not ok, rep)

# 7. 탐색 누락 감지: 처리하지 않는 위치의 텍스트
x = xp('보이는 문장') + '<hp:p><hp:unknownWrap><hp:t>숨은 문장</hp:t></hp:unknownWrap></hp:p>'
t, rep, ok = run('hidden', hwpx_file(x), '.hwpx')
case('구조 밖 텍스트 누락 감지', not ok and '추출 결과에 없습니다' in rep, rep)

# 8. 미리보기 인코딩
case('미리보기 UTF-16LE 영문', R.decode_preview('Hello World'.encode('utf-16-le')) == 'Hello World')
case('미리보기 UTF-8 끝 글자 잘림', R.decode_preview('가나다'.encode('utf-8')[:-1]) == '가나')
case('미리보기 BOM', R.decode_preview(b'\xef\xbb\xbf' + '가'.encode()) == '가')
x = xp('Hello World 문서')
t, rep, ok = run('prv16', hwpx_file(x, preview='Hello World'.encode('utf-16-le')), '.hwpx')
case('HWPX 미리보기 UTF-16LE 대조', ok and '100% 일치' in rep, rep)

# 9. 미리보기와 본문 불일치 -> 불완전
t, rep, ok = run('prvmiss', hwpx_file(xp('본문 내용'), preview='<본문 내용>\r\n<빠진 문장입니다>'.encode()), '.hwpx')
case('미리보기 누락 불완전 판정', not ok and '빠진문장입니다' in rep, rep)

# 10. 배포용 문서 -> 불완전
t, rep, ok = run('distrib', hwp_file(para(0, u16('x') + EOP), props=1 | 4, preview='앞부분 미리보기'), '.hwp')
case('배포용 문서 불완전 판정', not ok and '앞부분 미리보기' in t, rep)

# 11. 암호 문서 -> 실패
try:
    run('enc', hwp_file(b'', props=1 | 2), '.hwp')
    case('암호 문서 실패 처리', False, '예외 없음')
except R.ReadError as e:
    case('암호 문서 실패 처리', '암호' in str(e))

# 12. 깨짐 문자 감지
t, rep, ok = run('broken', hwpx_file(xp('범위ﾷ방향')), '.hwpx')
case('깨짐 의심 문자 감지', 'U+FFB7' in rep, rep)
t, rep, ok = run('halfpunct', hwpx_file(xp('｢중재법｣ 검수･검사')), '.hwpx')
case('반각 문장부호 오탐 없음', '깨짐 의심 문자: 없음' in rep, rep)

# 13. 지나치게 큰 표 -> 불완전
x = xtable_p([[xtc(0, 0, xp('a')), xtc(999, 999, xp('b'))]])
t, rep, ok = run('huge', hwpx_file(x), '.hwpx')
case('대형 표 제한', not ok and '너무 커서' in rep, rep)

# 14. 실제 셀이 시작하지 않는 전체 병합 행도 유지
x = xtable_p([[xtc(0, 0, xp('세로병합'), rs=3), xtc(0, 1, xp('우측'), rs=3)]])
t, rep, ok = run('span_rows', hwpx_file(x), '.hwpx')
case('병합만 존재하는 행 보존', ok and t.count('\n|  |  |') == 2, t)

# 15. 겹치는 셀 영역은 내용이 많아도 정상 처리로 오판하지 않음
x = xtable_p([[xtc(0, 0, xp('A'), cs=2), xtc(0, 1, xp('B'))]])
t, rep, ok = run('overlap', hwpx_file(x), '.hwpx')
case('겹치는 표 셀 영역 경고', not ok and '중첩/충돌' in rep, rep)

# 16. 실제 입력에서 텍스트 지문·표 셀 메타정보·근거 앵커 생성
x = xp('본문 자료') + xtable_p([[xtc(0, 0, xp('합계')), xtc(0, 1, xp('250백만원'))]])
p = os.path.join(TMP, 'details.hwpx')
with open(p, 'wb') as f:
    f.write(hwpx_file(x))
t, rep, ok, d = R.extract_details(p, anchors=True)
case('근거 앵커와 JSON 블록', ok and '〔S1-B0001〕' in t and
     d['blocks'][0]['anchor'] == 'S1-B0001' and d['status'] == 'text_structure_checked', str(d))
case('표 JSON 셀 좌표', d['tables'][0]['cells'][1]['col'] == 2 and
     d['tables'][0]['cells'][1]['text'] == '250백만원', str(d['tables']))
case('문자 지문 대조 표시', '텍스트 조각 대조:' in rep and '일치' in rep, rep)

# 17. 구역 번호 간격과 ZIP 중복 항목 검출
import io
b = io.BytesIO()
with zipfile.ZipFile(b, 'w') as z:
    z.writestr('Contents/section0.xml', f'<hs:sec {NS}>{xp("첫 구역")}</hs:sec>')
    z.writestr('Contents/section2.xml', f'<hs:sec {NS}>{xp("셋째 구역")}</hs:sec>')
t, rep, ok = run('gap', b.getvalue(), '.hwpx')
case('HWPX 구역 번호 누락 감지', not ok and '연속되지 않습니다' in rep, rep)

# 18. 문서에 보이는 비텍스트 객체 한계 보고
x = '<hp:p><hp:run><hp:t>설명</hp:t><hp:pic/></hp:run></hp:p>'
t, rep, ok = run('picture', hwpx_file(x), '.hwpx')
case('이미지 비해석 고지', ok and 'pic 1개' in rep, rep)

# 19. DTD·XML ENTITY를 실행하지 않고 안전하게 생략
b = io.BytesIO()
with zipfile.ZipFile(b, 'w') as z:
    z.writestr('Contents/section0.xml', f'<!DOCTYPE x [<!ENTITY payload "oops">]><hs:sec {NS}>{xp("문장")}</hs:sec>')
t, rep, ok = run('unsafe_dtd', b.getvalue(), '.hwpx')
case('DTD·ENTITY 안전 차단', not ok and 'DTD/ENTITY' in rep, rep)

# 20. ZIP 내부 크기 한도 초과는 결과를 불완전으로 표시
limit = R.MAX_XML_BYTES
try:
    R.MAX_XML_BYTES = 50
    t, rep, ok = run('limit_xml', hwpx_file(xp('용량초과 문장')), '.hwpx')
finally:
    R.MAX_XML_BYTES = limit
case('압축 해제 제한', not ok and '너무 커서' in rep, rep)

# 21. CLI의 Markdown·JSON 동시 출력 및 종료 코드
mdp, jsp = os.path.join(TMP, 'out.md'), os.path.join(TMP, 'out.json')
cmd = [sys.executable, '-I', R.__file__, p, '--anchors', '-o', mdp, '--json-output', jsp]
completed = subprocess.run(cmd, text=True, capture_output=True)
try:
    output_json = json.load(open(jsp, encoding='utf-8'))
except (OSError, ValueError):
    output_json = {}
case('CLI Markdown·JSON 동시 생성', completed.returncode == 0 and os.path.exists(mdp) and
     output_json.get('status') == 'text_structure_checked', completed.stderr)

# 22. 유효하지 않은 OLE sector shift 거부
blob = bytearray(hwp_file(para(0, u16('본문') + EOP)))
struct.pack_into('<H', blob, 0x1E, 0xFFFF)
try:
    run('badsector', blob, '.hwp')
    case('손상된 OLE 헤더 거부', False)
except R.ReadError as e:
    case('손상된 OLE 헤더 거부', '섹터' in str(e), str(e))

# 실제 문서(선택)
for p in sys.argv[1:]:
    try:
        t, rep, ok = R.extract(p)
        print(f'\n[실제 문서] {os.path.basename(p)}\n{rep}')
    except R.ReadError as e:
        print(f'\n[실제 문서] {os.path.basename(p)} — 실패: {e}')

print(f'\n{sum(results)}/{len(results)} 통과')
sys.exit(0 if all(results) else 1)
