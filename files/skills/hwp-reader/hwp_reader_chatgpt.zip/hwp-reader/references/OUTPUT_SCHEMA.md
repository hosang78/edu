# ChatGPT용 구조화 추출 결과 형식

`python3 -I scripts/read_hwp.py file.hwp --anchors -o output.md --json-output output.json`

## JSON 스키마 개요

```json
{
  "schema_version": "1.0",
  "filename": "예시.hwpx",
  "format": "HWPX",
  "status": "text_structure_checked",
  "status_meaning": "supported text structure check passed; not full visual fidelity",
  "limitations": ["..."],
  "counts": {"sections": 1, "paragraphs_seen": 3, "tables": 1},
  "objects": {"pic": 1},
  "warnings": [],
  "notes": [],
  "source_sections": ["Contents/section0.xml"],
  "blocks": [
    {"anchor": "S1-B0001", "section": 1, "block_index": 1, "kind": "text", "text": "본문"},
    {"anchor": "S1-B0002", "section": 1, "block_index": 2, "kind": "table", "text": "[표 1] ..."}
  ],
  "tables": [
    {"number": 1, "parent_table": null, "caption": "", "cells": [
      {"row": 1, "col": 1, "rowspan": 1, "colspan": 2, "text": "병합 제목"}
    ]}
  ],
  "diagnostic_text": "[점검] ..."
}
```

### 주의
- `status=text_structure_checked`는 **지원 대상 텍스트를 확인한 결과**다. 원본 렌더링과 동일하다는 보장이 아니다.
- `blocks[].anchor`의 `S`는 출력 구역 번호, `B`는 구역 내 출력 블록 순서. HWP 원본 페이지 번호 아님.
- 표 셀 좌표는 1부터 시작한다. 원본에 없는 병합 커버 영역은 Markdown에서는 빈 셀로 표시될 수 있으나, 실제 병합 범위는 JSON `rowspan`/`colspan`에 보존.
- `source_sections`는 HWPX 구역 XML 파일명만 보유하며 HWP는 비어 있을 수 있음.
- `images_or_bindata` 카운트는 자산을 뜻하며 **시각 이미지의 정확한 개수로 사용하면 안 됨**.
- XML 검사는 그림 속 문자, 배치로 인한 의미 왜곡, 스타일 차이를 검출하지 못함.
- 사용자 응답에 원문 전체를 인용하지 말고 필요한 근거만 제시.
