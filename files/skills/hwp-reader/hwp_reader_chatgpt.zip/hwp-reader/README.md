# hwp-reader — ChatGPT 분석용 HWP/HWPX Reader

한글(HWP/HWPX) 문서 본문과 표를 읽기 전용으로 추출하여 ChatGPT가 요약, 질의응답, 문서 비교, 내용 검수에 활용할 수 있도록 준비한 스킬 패키지입니다.

## 구성
- `SKILL.md` : AI가 따라야 할 작업 절차·증거 규칙·한계
- `scripts/read_hwp.py` : 순수 Python HWP/HWPX → Markdown·JSON 추출
- `references/OUTPUT_SCHEMA.md` : JSON/앵커/표 좌표 안내
- `tests/run_tests.py` : 합성 HWP/HWPX 회귀시험 31항목

## 빠른 실행
```bash
python3 -I scripts/read_hwp.py "문서.hwpx" --anchors -o 결과.md --json-output 결과.json
python3 -I tests/run_tests.py
```

스크립트의 종료 코드가 0이어도 화면에서 보이는 도형·이미지·수식과 원본 페이지 배치는 보증되지 않습니다. 결재·법규·계약 등 고위험 문서는 원본 한글 프로그램 또는 PDF 대조가 필요합니다.

이 패키지는 자동으로 ChatGPT 계정에 설치되지 않습니다. 스킬 실행을 지원하는 환경에서 파일을 등록하거나, 코드 실행 환경에서 스킬의 절차대로 활용하는 용도입니다.
