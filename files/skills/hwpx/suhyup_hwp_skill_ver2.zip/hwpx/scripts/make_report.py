#!/usr/bin/env python3
"""JSON 명세 → 보고서 HWPX 한 번에 생성 (빌드 + 검증 + 최종화).

사용:
  python3 make_report.py spec.json -o report.hwpx

spec.json 예:
{
  "title": "보고서 제목", "meta": "2026년 10월 10일  OO팀", "creator": "OO팀",
  "blocks": [
    {"type": "section", "text": "추진 배경", "page_break": false},
    {"type": "bullet", "text": "**핵심어**는 굵게", "level": 1},
    {"type": "table", "widths": [8000, 18000, 16520], "align": ["c","l","l"], "label_col": true,
     "rows": [["구분","내용","비고"], ["A","설명",{"t":"병합","cs":1}]]},
    {"type": "note", "text": "※ 주석"}
  ]
}
type: title | meta | section | bullet | text | note | box | table | spacer
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import hwpx_blocks  # noqa: E402
from hwpx_blocks import Doc  # noqa: E402


def run(cmd: list[str]) -> None:
    # 주의: -I 옵션을 쓰면 형제 모듈 import가 실패하므로 쓰지 않는다
    r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode != 0:
        print(r.stderr.strip(), file=sys.stderr)
        raise SystemExit(f"실패: {' '.join(Path(c).name for c in cmd[:2])}")


def build_doc(spec: dict) -> Doc:
    d = Doc("report")
    if spec.get("title"):
        d.title(spec["title"])
    if spec.get("meta"):
        d.meta(spec["meta"])
        d.spacer()
    for b in spec["blocks"]:
        t = b["type"]
        if t == "section":
            d.section(b["text"], b.get("page_break", False))
        elif t == "bullet":
            d.bullet(b["text"], b.get("level", 1), b.get("attach"), b.get("right"))
        elif t == "text":
            d.text(b["text"], b.get("attach", False))
        elif t == "note":
            d.note(b["text"])
        elif t == "box":
            d.box(b["lines"], fill=b.get("fill", False))
            d.spacer()
        elif t == "spacer":
            d.spacer()
        elif t == "table":
            d.table(b["rows"], b.get("widths"), b.get("header_rows", 1), b.get("align"),
                    b.get("label_col", False), b.get("row_h", 2600), b.get("style", "open"),
                    b.get("header_fill"), b.get("total_row", False), b.get("vlines", True),
                    head_line=b.get("head_line", "double"), indent=b.get("indent", 1), label_cols=b.get("label_cols"))
        else:
            raise SystemExit(f"알 수 없는 블록 type: {t}")
    return d


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--hanging", action="store_true",
                    help="내어쓰기 켜기(기본 꺼짐). 켜 보았으나 PC 한글·모바일 뷰어 모두 ○·- 위치가 어긋나는 것이 확인됨. 필요하면 문서 완성 후 한글에서 Shift+Tab으로 직접 맞춘다")
    args = ap.parse_args()

    spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
    hwpx_blocks.HANGING = bool(args.hanging or spec.get("hanging", False))
    doc = build_doc(spec)
    out = str(Path(args.output).resolve())
    with tempfile.TemporaryDirectory() as td:
        sec, hdr = Path(td, "section0.xml"), Path(td, "header.xml")
        sec.write_text(doc.to_xml(), encoding="utf-8")
        hdr.write_text(doc.header_xml(), encoding="utf-8")
        run([str(HERE / "build_hwpx.py"), "--template", "report", "--header", str(hdr), "--section", str(sec),
             "--title", spec.get("title", ""), "--creator", spec.get("creator", ""), "--output", out])
    run([str(HERE / "validate.py"), out])
    run([str(HERE / "fix_namespaces.py"), out])
    run([str(HERE / "finalize_hwpx.py"), out, "--strip-linesegarray", "--layout"])
    run([str(HERE / "validate.py"), out, "--layout"])
    print("완료:", out)


if __name__ == "__main__":
    main()
