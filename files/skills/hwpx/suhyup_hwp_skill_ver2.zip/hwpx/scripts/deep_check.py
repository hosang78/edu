#!/usr/bin/env python3
"""HWPX 심층 정합성 검사 (validate.py가 놓치는 항목).

검사 항목
- header.xml 그룹별 itemCnt == 실제 자식 수, ID 중복 없음
- section의 charPrIDRef / paraPrIDRef / borderFillIDRef가 header에 존재
- 문단 id, 표 id 전역 중복 없음
- 표: rowCnt/colCnt와 실제 셀 배치(병합 포함)가 빈틈·겹침 없이 일치, 행별 셀 너비 합 == 표 너비
- 쪽 나눔 수(pageBreak="1") 보고(예상 최소 쪽수)

사용: python3 deep_check.py file.hwpx   (실패 시 종료코드 1)
"""
from __future__ import annotations

import re
import sys
import zipfile
from collections import Counter

from lxml import etree

HP = "http://www.hancom.co.kr/hwpml/2011/paragraph"
HH = "http://www.hancom.co.kr/hwpml/2011/head"
NS = {"hp": HP, "hh": HH}


def check(path: str) -> list[str]:
    errs: list[str] = []
    z = zipfile.ZipFile(path)
    hdr = etree.fromstring(z.read("Contents/header.xml"))
    secs = [n for n in z.namelist() if re.fullmatch(r"Contents/section\d+\.xml", n)]

    ids: dict[str, set[str]] = {}
    for group, item in (("charProperties", "charPr"), ("paraProperties", "paraPr"),
                        ("borderFills", "borderFill"), ("numberings", "numbering"), ("styles", "style")):
        g = hdr.find(f".//hh:{group}", NS)
        if g is None:
            continue
        kids = g.findall(f"hh:{item}", NS)
        if int(g.get("itemCnt", -1)) != len(kids):
            errs.append(f"{group}: itemCnt={g.get('itemCnt')} 실제={len(kids)}")
        got = [k.get("id") for k in kids]
        dup = [i for i, c in Counter(got).items() if c > 1]
        if dup:
            errs.append(f"{group}: ID 중복 {dup}")
        ids[item] = set(got)

    pids: list[str] = []
    tids: list[str] = []
    breaks = 0
    for name in secs:
        sec = etree.fromstring(z.read(name))
        for el in sec.iter():
            for attr, kind in (("charPrIDRef", "charPr"), ("paraPrIDRef", "paraPr"), ("borderFillIDRef", "borderFill")):
                v = el.get(attr)
                if v is not None and kind in ids and v not in ids[kind]:
                    errs.append(f"{name}: {el.tag.split('}')[1]} {attr}={v} 가 header에 없음")
        for p in sec.iter(f"{{{HP}}}p"):
            pids.append(p.get("id"))
            if p.get("pageBreak") == "1":
                breaks += 1
        for tbl in sec.iter(f"{{{HP}}}tbl"):
            tids.append(tbl.get("id"))
            rows, cols = int(tbl.get("rowCnt")), int(tbl.get("colCnt"))
            tw = int(tbl.find("hp:sz", NS).get("width"))
            grid: dict[tuple[int, int], int] = {}
            rowsum: dict[int, int] = {}
            for tc in tbl.iter(f"{{{HP}}}tc"):
                a = tc.find("hp:cellAddr", NS)
                s = tc.find("hp:cellSpan", NS)
                z_ = tc.find("hp:cellSz", NS)
                c0, r0 = int(a.get("colAddr")), int(a.get("rowAddr"))
                cs, rs = int(s.get("colSpan")), int(s.get("rowSpan"))
                w = int(z_.get("width"))
                rowsum[r0] = rowsum.get(r0, 0) + w
                for r in range(r0, r0 + rs):
                    for c in range(c0, c0 + cs):
                        grid[(r, c)] = grid.get((r, c), 0) + 1
            holes = [(r, c) for r in range(rows) for c in range(cols) if (r, c) not in grid]
            overl = [k for k, v in grid.items() if v > 1]
            outside = [k for k in grid if k[0] >= rows or k[1] >= cols]
            if holes or overl or outside:
                errs.append(f"{name}: 표(id={tbl.get('id')}) 셀 배치 불일치 빈칸={holes[:3]} 겹침={overl[:3]} 범위밖={outside[:3]}")
            # 세로 병합으로 가려진 칸이 있는 행은 합계가 작을 수 있어 첫 행만 엄격 검사
            if rowsum.get(0, tw) != tw:
                errs.append(f"{name}: 표(id={tbl.get('id')}) 첫 행 셀 너비 합 {rowsum.get(0)} != 표 너비 {tw}")
    for label, lst in (("문단 id", pids), ("표 id", tids)):
        dup = [i for i, c in Counter(lst).items() if c > 1 and i is not None]
        if dup:
            errs.append(f"{label} 중복: {dup[:5]}")
    print(f"문단 {len(pids)}개, 표 {len(tids)}개, 쪽 나눔 {breaks}회 → 최소 {breaks + 1}쪽")
    return errs


if __name__ == "__main__":
    e = check(sys.argv[1])
    if e:
        print("DEEP CHECK FAIL")
        for x in e:
            print(" -", x)
        sys.exit(1)
    print("DEEP CHECK PASS")
