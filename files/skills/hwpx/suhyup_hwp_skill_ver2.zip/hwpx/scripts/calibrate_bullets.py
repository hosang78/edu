#!/usr/bin/env python3
"""글머리 위치 보정용 시험 문서 생성.

뷰어마다 내어쓰기(intent) 처리가 달라 ○/- 위치가 어긋날 수 있다. 이 스크립트는 첫 줄 위치와
내어쓰기 폭을 바꾼 변형을 한 문서에 담는다. 사용자 화면에서 가장 알맞은 변형을 골라
hwpx_blocks.POS_L1/TXT_L1 등 상수에 반영한다.

  python3 calibrate_bullets.py -o bullet_calibration.hwpx
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import hwpx_blocks as hb  # noqa: E402
from hwpx_blocks import Doc  # noqa: E402

LONG = "기업의 주요 업무에 생성형 AI를 직접 활용하려는 수요가 빠르게 증가하고 있어 사전 검토가 필요함"
# (이름, 첫 줄 위치, 이어지는 줄 위치)
VARIANTS = [("A", 600, 2300), ("B", 600, 1800), ("C", 600, 1400), ("D", 0, 1700), ("E", 0, 1200), ("F", 600, 600)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--output", required=True)
    args = ap.parse_args()
    d = Doc("report")
    d.title("글머리 위치 보정")
    d.section("기준: □ 제목 줄")
    pps = []
    for name, first, text in VARIANTS:
        pps.append((text, first - text))                 # (left, intent)
    ids = [40 + i for i in range(len(VARIANTS))]
    for (name, first, text), pid in zip(VARIANTS, ids):
        label = f"({name}: 첫줄 {first}, 이어짐 {text})"
        d.parts.append(d._p(f"○ {LONG} {label}", pid, hb.CP_BODY, hb.CP_BOLD))
        d.parts.append(d._p(f"-" + f" {LONG} {label}", pid, hb.CP_BODY, hb.CP_BOLD))
    with tempfile.TemporaryDirectory() as td:
        sec, hdr = Path(td, "s.xml"), Path(td, "h.xml")
        sec.write_text(d.to_xml(), encoding="utf-8")
        hdr.write_text(hb.patched_header("report", d.bf_specs, pps), encoding="utf-8")
        r = subprocess.run([sys.executable, str(HERE / "build_hwpx.py"), "--template", "report", "--header", str(hdr),
                            "--section", str(sec), "--title", "글머리 보정", "--output", args.output],
                           capture_output=True, text=True)
        print(r.stdout.strip() or r.stderr.strip())
    for cmd in (["fix_namespaces.py"], ["finalize_hwpx.py", "--strip-linesegarray", "--layout"]):
        subprocess.run([sys.executable, str(HERE / cmd[0]), args.output, *cmd[1:]], capture_output=True)
    print("완료:", args.output)


if __name__ == "__main__":
    main()
