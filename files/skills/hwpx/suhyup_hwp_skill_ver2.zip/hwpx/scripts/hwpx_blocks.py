#!/usr/bin/env python3
"""보고서(report 템플릿)용 블록 생성 라이브러리.

section0.xml을 손으로 쓰면 필수 구조 누락으로 한글에서 열리지 않는 사고가 잦다.
이 모듈은 검증된 템플릿 스타일 위에 제목/개조식/표/요약박스/쪽나눔을 안전하게 만든다.

핵심 원칙
- 섹션 제목은 '문단 테두리' 대신 1x1 표로 만든다. 문단 테두리는 뷰어(모바일 등)에 따라
  아래선이 본문과 겹쳐 보이는 문제가 있었다. 표 테두리는 모든 뷰어에서 안정적이다.
- 글머리(ㅇ, -, ·)는 내어쓰기(hanging indent) 문단 스타일로 줄바꿈 시 글자 정렬이 맞는다.
- header.xml에는 새 스타일만 '추가'하고 itemCnt를 갱신한다(기존 ID는 변경하지 않는다).
"""
from __future__ import annotations

import re
from pathlib import Path
from xml.sax.saxutils import escape

SKILL_DIR = Path(__file__).resolve().parent.parent
BODY_W = 48190  # A4 본문폭(HWPUNIT) = 59528 - 5669×2 (좌우 여백 20mm)

# ---- 템플릿 기존 스타일 ID (report) ----
CP_BODY10 = 0      # 10pt 바탕
CP_TITLE = 7       # 20pt 볼드
CP_TH = 9          # 10pt 볼드(표 머리글)
CP_SMALL = 11      # 9pt (주석)
CP_H = 13          # 12pt 볼드 돋움(섹션 제목)
PP_JUSTIFY0 = 0
PP_TITLE = 20      # 가운데
PP_CELL_C = 21     # 표 셀 가운데 130%
PP_CELL_L = 22     # 표 셀 양쪽 130%
PP_RIGHT = 23      # 오른쪽 160%
BF_NONE = 2        # 없음
BF_GRID = 3        # 4면 실선
BF_HEAD = 4        # 4면 실선 + #F2F2F2

# ---- 이 모듈이 header.xml에 추가하는 스타일 ID ----
CP_BODY = 16       # 12pt 바탕(본문)
CP_BOLD = 17       # 12pt 볼드 바탕(본문 강조)
BF_SECTION = 7     # 섹션 제목: 위 0.4mm + 아래 0.12mm, 좌우 없음
BF_BOX = 8         # 요약 박스: 4면 실선 + #F2F2F2
BF_LABEL = 9       # 라벨 셀: 4면 실선 + #F2F2F2
PP_L1 = 28         # ○  (기호 시작 POS_L1)
PP_L2 = 29         # -   (첫줄 2000, 이어지는 줄 2900)
PP_L3 = 30         # ·   (첫줄 3000, 이어지는 줄 3800)
PP_CELL_R = 31     # 표 셀 오른쪽 130%
PP_TEXT = 32       # 들여쓰기 없는 본문(왼쪽 600)
CP_CELL = 18       # 11pt 바탕(표 본문)
CP_CELL_B = 19     # 11pt 볼드 바탕(표 머리글·라벨)
CP_TINY = 20       # 1pt (예비)
CP_DASH = 21       # 12pt, 장평 60%: 글머리 '-'가 길어 보이지 않게
CP_TINY = 20       # 1pt(제목 아래 두 줄 선 사이 간격 행용)
PP_CELLB = 33      # 표 셀 안 • 글머리(내어쓰기, 왼쪽 맞춤)
PP_UNIT = 39      # ○ 항목 + 오른쪽 끝 탭(단위 표기용)
PP_TBL_IND = {1: 36, 2: 37, 3: 38}   # 표 들여쓰기 문단(왼쪽 1200/1500/2300): ○ 글자 시작·- 글자 시작·· 글자 시작에 맞춤
PP_SECTION = 35    # 섹션 제목 문단(위 간격 10pt, 선 없음)
PP_CELL_LL = 34    # 표 셀 왼쪽 정렬 130%(양쪽 맞춤 대신: 글자 사이가 벌어지지 않게)
DYN_BF_START = 10  # 표 테두리 조합용 borderFill은 10번부터 동적 추가

THIN, MID, THICK = "0.12 mm", "0.3 mm", "0.4 mm"
DOUBLE = "DOUBLE_SLIM"   # 두 줄 선(굵기 0.5mm로 기록)
GRAY = "#F2F2F2"
# 내어쓰기(이어지는 줄을 글자 시작 위치에 맞춤)는 기본 꺼짐. 켜 보았으나 모바일 한컴 뷰어가 intent를 약 절반만 반영해
# ○ 위치가 어긋나(bullet_calibration 시험 결과) 원복했다. 첫 줄·이어지는 줄이 같은 위치에서 시작한다.
HANGING = False   # 기본 꺼짐. 켜면 PC·모바일 모두 위치가 어긋나는 것이 확인됨(make_report.py --hanging 으로만 켠다)
# 글머리 기호 시작 위치(HWPUNIT, 본문 왼쪽 끝=0). ○는 □보다 한 칸, -는 ○보다 한 칸 안쪽.
POS_L1, POS_L2, POS_L3 = 600, 1200, 1800   # 기호 시작 위치(HWPUNIT). 600 ≈ 12pt 스페이스 한 칸
TXT_L1, TXT_L2, TXT_L3 = POS_L1 + 1700, POS_L2 + 800, POS_L3 + 800   # HANGING=True일 때만 사용   # 기호 뒤 글자 시작(내어쓰기용)
TBL_INDENT = {0: 0, 1: POS_L1, 2: POS_L2, 3: POS_L3}        # 이 스킬에서 쓰는 유일한 배경색(옅은 회색)
PAD = (800, 800, 220, 220)  # 셀 여백 좌·우·상·하(HWPUNIT). 글자가 선에 붙지 않도록 넉넉히


def _bf(idx: int, left, right, top, bottom, fill: str | None) -> str:
    """각 변 값은 굵기 문자열(예 "0.12 mm") 또는 None(선 없음)."""
    def side(tag: str, w) -> str:
        if not w:
            return f'<hh:{tag} type="NONE" width="0.1 mm" color="#000000"/>'
        if w == DOUBLE:
            return f'<hh:{tag} type="DOUBLE_SLIM" width="0.5 mm" color="#000000"/>'
        return f'<hh:{tag} type="SOLID" width="{w}" color="#000000"/>'
    brush = (f'<hc:fillBrush><hc:winBrush faceColor="{fill}" hatchColor="#999999" alpha="0"/></hc:fillBrush>'
             if fill else "")
    return (f'<hh:borderFill id="{idx}" threeD="0" shadow="0" centerLine="NONE" breakCellSeparateLine="0">'
            '<hh:slash type="NONE" Crooked="0" isCounter="0"/>'
            '<hh:backSlash type="NONE" Crooked="0" isCounter="0"/>'
            + side("leftBorder", left) + side("rightBorder", right)
            + side("topBorder", top) + side("bottomBorder", bottom)
            + '<hh:diagonal type="SOLID" width="0.12 mm" color="#000000"/>'
            + brush + '</hh:borderFill>')


def _charpr(idx: int, height: int, bold: bool, ratio: int = 100) -> str:
    return (f'<hh:charPr id="{idx}" height="{height}" textColor="#000000" shadeColor="none" useFontSpace="0" '
            'useKerning="0" symMark="NONE" borderFillIDRef="2">'
            '<hh:fontRef hangul="1" latin="1" hanja="1" japanese="1" other="1" symbol="1" user="1"/>'
            f'<hh:ratio hangul="{ratio}" latin="{ratio}" hanja="{ratio}" japanese="{ratio}" other="{ratio}" symbol="{ratio}" user="{ratio}"/>'
            '<hh:spacing hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>'
            '<hh:relSz hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/>'
            '<hh:offset hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>'
            + ('<hh:bold/>' if bold else '') +
            '<hh:underline type="NONE" shape="SOLID" color="#000000"/>'
            '<hh:strikeout shape="NONE" color="#000000"/>'
            '<hh:outline type="NONE"/>'
            '<hh:shadow type="NONE" color="#C0C0C0" offsetX="10" offsetY="10"/>'
            '</hh:charPr>')


def _pos(first: int, text_start: int) -> tuple:
    """(정렬, left, intent) — HANGING이면 내어쓰기, 아니면 첫 줄 위치만 사용."""
    return ("LEFT", text_start, first - text_start) if HANGING else ("LEFT", first, 0)


def _parapr(idx: int, align: str, left: int, intent: int, line: int, prev: int = 0, nxt: int = 0, tab: int = 0) -> str:
    # hp:switch 필수. case=HwpUnitChar 값, default=2배(템플릿 관례)
    def margin(k: int) -> str:
        return ('<hh:margin>'
                f'<hc:intent value="{intent * k}" unit="HWPUNIT"/>'
                f'<hc:left value="{left * k}" unit="HWPUNIT"/>'
                '<hc:right value="0" unit="HWPUNIT"/>'
                f'<hc:prev value="{prev * k}" unit="HWPUNIT"/>'
                f'<hc:next value="{nxt * k}" unit="HWPUNIT"/>'
                '</hh:margin>'
                f'<hh:lineSpacing type="PERCENT" value="{line}" unit="HWPUNIT"/>')
    return (f'<hh:paraPr id="{idx}" tabPrIDRef="{tab}" condense="0" fontLineHeight="0" snapToGrid="1" '
            'suppressLineNumbers="0" checked="0" textDir="LTR">'
            f'<hh:align horizontal="{align}" vertical="BASELINE"/>'
            '<hh:heading type="NONE" idRef="0" level="0"/>'
            '<hh:breakSetting breakLatinWord="KEEP_WORD" breakNonLatinWord="BREAK_WORD" widowOrphan="0" '
            'keepWithNext="0" keepLines="0" pageBreakBefore="0" lineWrap="BREAK"/>'
            '<hh:autoSpacing eAsianEng="0" eAsianNum="0"/>'
            '<hp:switch>'
            '<hp:case hp:required-namespace="http://www.hancom.co.kr/hwpml/2016/HwpUnitChar">'
            + margin(1) + '</hp:case><hp:default>' + margin(2) + '</hp:default></hp:switch>'
            '<hh:border borderFillIDRef="2" offsetLeft="0" offsetRight="0" offsetTop="0" offsetBottom="0" '
            'connect="0" ignoreMargin="0"/></hh:paraPr>')


def patched_header(template: str = "report", extra_bf: list[tuple] | None = None,
                   extra_pp: list[tuple] | None = None) -> str:
    """report 템플릿 header.xml에 보고서용 스타일을 추가한 문자열을 반환."""
    h = (SKILL_DIR / "templates" / template / "header.xml").read_text(encoding="utf-8")

    def add(h: str, group: str, item_tag: str, items: list[str], first_id: int) -> str:
        m = re.search(rf"<hh:{group} itemCnt=\"(\d+)\"", h)
        cnt = int(m.group(1))
        ids = [int(x) for x in re.findall(rf'<hh:{item_tag} id="(\d+)"', h[m.start():h.index(f"</hh:{group}>")])]
        assert max(ids) + 1 == first_id, f"{group}: 다음 ID가 {max(ids)+1}인데 {first_id}로 추가하려 함(템플릿 변경됨)"
        h = h.replace(m.group(0), f'<hh:{group} itemCnt="{cnt + len(items)}"', 1)
        return h.replace(f"</hh:{group}>", "".join(items) + f"</hh:{group}>", 1)

    h = add(h, "charProperties", "charPr",
            [_charpr(CP_BODY, 1200, False), _charpr(CP_BOLD, 1200, True),
             _charpr(CP_CELL, 1100, False), _charpr(CP_CELL_B, 1100, True),
             _charpr(CP_TINY, 100, False), _charpr(CP_DASH, 1200, False, 60)], CP_BODY)
    h = add(h, "borderFills", "borderFill",
            [_bf(BF_SECTION, None, None, THICK, THIN, None),
             _bf(BF_BOX, THIN, THIN, THIN, THIN, GRAY),
             _bf(BF_LABEL, THIN, THIN, THIN, THIN, GRAY)]
            + [_bf(DYN_BF_START + i, *spec) for i, spec in enumerate(extra_bf or [])], BF_SECTION)
    h = add(h, "paraProperties", "paraPr",
            [_parapr(PP_L1, *_pos(POS_L1, TXT_L1), 160),
             _parapr(PP_L2, *_pos(POS_L2, TXT_L2), 160),
             _parapr(PP_L3, *_pos(POS_L3, TXT_L3), 160),
             _parapr(PP_CELL_R, "RIGHT", 0, 0, 130),
             _parapr(PP_TEXT, "LEFT", 600, 0, 160),
             _parapr(PP_CELLB, *_pos(0, 900), 130),
             _parapr(PP_CELL_LL, "LEFT", 0, 0, 130),
             _parapr(PP_SECTION, "LEFT", 0, 0, 160, 1000, 300),
             _parapr(36, "LEFT", POS_L1, 0, 160), _parapr(37, "LEFT", POS_L2, 0, 160), _parapr(38, "LEFT", POS_L3, 0, 160),
             _parapr(PP_UNIT, *_pos(POS_L1, TXT_L1), 160, tab=2)]      # 오른쪽 끝 자동 탭(tabPr 2): (단위 : …)를 줄 오른쪽 끝에
            + [_parapr(40 + i, "LEFT", left, intent, 160) for i, (left, intent) in enumerate(extra_pp or [])], PP_L1)
    return h


class Doc:
    """블록을 쌓아 section0.xml 문자열을 만든다."""

    def __init__(self, template: str = "report"):
        self.template = template
        self._pid = 1000000001
        self._tid = 1000000100
        self.parts: list[str] = []
        self._after_tbl = False            # 직전 블록이 표(또는 표에 붙은 ※ 주석·- 항목)인지
        self._tbl_pp = PP_TEXT             # 표에 붙는 주석/- 항목의 문단 스타일(표 들여쓰기와 같은 왼쪽 위치)
        self.bf_specs: list[tuple] = []   # 표 테두리 조합(동적 borderFill), ID = DYN_BF_START + index
        tpl = (SKILL_DIR / "templates" / template / "section0.xml").read_text(encoding="utf-8")
        root_end = tpl.index(">", tpl.index("<hs:sec")) + 1
        self.root_open = tpl[:root_end]
        first_end = tpl.index("</hp:p>") + len("</hp:p>")
        first = re.sub(r"<!--.*?-->", "", tpl[root_end:first_end], flags=re.S)
        first = re.sub(r"<hp:linesegarray>.*?</hp:linesegarray>", "", first, flags=re.S)
        self.parts.append(first)  # secPr/colPr 포함 첫 문단(필수)

    # ---- 내부 도우미 ----
    def _id(self) -> int:
        self._pid += 1
        return self._pid

    def _tbl_id(self) -> int:
        self._tid += 1
        return self._tid

    @staticmethod
    def _runs(text: str, cp: int, cp_bold: int | None) -> str:
        """'**굵게**' 표기를 런으로 분리. cp_bold 없으면 굵게 표기를 무시.
        사내 표기 규칙: 콜론은 앞뒤에 스페이스 한 칸('목적: 이' → '목적 : 이'). 시각(9:30)·URL처럼 뒤에 공백이 없는 콜론은 건드리지 않는다."""
        text = re.sub(r"(?<=\S)[ ]*:(?:[ ]+(?=\S)|$)", lambda m: " :" + (" " if m.group(0).endswith(" ") else ""), text)
        out = ""
        for i, seg in enumerate(re.split(r"\*\*", text)):
            if seg == "":
                continue
            c = cp_bold if (i % 2 == 1 and cp_bold is not None) else cp
            out += f'<hp:run charPrIDRef="{c}"><hp:t>{escape(seg)}</hp:t></hp:run>'
        return out or f'<hp:run charPrIDRef="{cp}"><hp:t/></hp:run>'

    def _p(self, text: str, pp: int, cp: int, cp_bold: int | None = None, page_break: bool = False) -> str:
        return (f'<hp:p id="{self._id()}" paraPrIDRef="{pp}" styleIDRef="0" pageBreak="{1 if page_break else 0}" '
                f'columnBreak="0" merged="0">{self._runs(text, cp, cp_bold)}</hp:p>')

    def _bf_id(self, left, right, top, bottom, fill=None) -> int:
        spec = (left, right, top, bottom, fill)
        if spec not in self.bf_specs:
            self.bf_specs.append(spec)
        return DYN_BF_START + self.bf_specs.index(spec)

    def header_xml(self) -> str:
        """이 문서가 쓰는 동적 borderFill까지 포함한 header.xml."""
        return patched_header(self.template, self.bf_specs)

    def _cell(self, paras: str, col: int, row: int, w: int, h: int, bf: int,
              cs: int = 1, rs: int = 1, margin=PAD) -> str:
        # hasMargin="1": 셀 자체 여백 사용. 0이면 표 안쪽 여백(inMargin)을 따르는데
        # 예전 구현은 inMargin=0이라 글자가 선에 붙어 나왔다.
        l, r, t, b = margin
        return ('<hp:tc name="" header="0" hasMargin="1" protect="0" editable="0" dirty="1" '
                f'borderFillIDRef="{bf}">'
                '<hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="CENTER" '
                'linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">'
                + paras + '</hp:subList>'
                f'<hp:cellAddr colAddr="{col}" rowAddr="{row}"/>'
                f'<hp:cellSpan colSpan="{cs}" rowSpan="{rs}"/>'
                f'<hp:cellSz width="{w}" height="{h}"/>'
                f'<hp:cellMargin left="{l}" right="{r}" top="{t}" bottom="{b}"/>'
                '</hp:tc>')

    def _tbl(self, rows_xml: str, nrows: int, ncols: int, height: int, bf: int = BF_GRID,
             inm=PAD, width: int = BODY_W, pp: int = 0) -> str:
        l, r, t, b = inm
        return (f'<hp:p id="{self._id()}" paraPrIDRef="{pp}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">'
                '<hp:run charPrIDRef="0">'
                f'<hp:tbl id="{self._tbl_id()}" zOrder="0" numberingType="TABLE" textWrap="TOP_AND_BOTTOM" '
                'textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" pageBreak="CELL" repeatHeader="0" '
                f'rowCnt="{nrows}" colCnt="{ncols}" cellSpacing="0" borderFillIDRef="{bf}" noAdjust="0">'
                f'<hp:sz width="{width}" widthRelTo="ABSOLUTE" height="{height}" heightRelTo="ABSOLUTE" protect="0"/>'
                '<hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" '
                'holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="COLUMN" vertAlign="TOP" '
                'horzAlign="LEFT" vertOffset="0" horzOffset="0"/>'
                '<hp:outMargin left="0" right="0" top="0" bottom="0"/>'
                f'<hp:inMargin left="{l}" right="{r}" top="{t}" bottom="{b}"/>'
                + rows_xml + '</hp:tbl><hp:t/></hp:run></hp:p>')

    # ---- 공개 블록 ----
    def title(self, text: str):
        """문서 제목: 가운데 20pt 볼드 한 줄(배경·선 없음)."""
        self.parts.append(self._p(text, PP_TITLE, CP_TITLE))
        return self

    def meta(self, text: str):
        """제목 아래 우측 정렬 한 줄(날짜·부서 등)."""
        self.parts.append(self._p(text, PP_RIGHT, CP_BODY10))
        return self

    def spacer(self):
        """빈 줄 1개(본문 12pt 엔터)."""
        self.parts.append(self._p("", PP_JUSTIFY0, CP_BODY))
        self._after_tbl = False
        return self

    def _gap(self):
        """표 바로 아래에 ○ 항목·본문·박스·다른 표가 오면 빈 줄을 넣는다. (※ 주석은 표에 붙인다)"""
        if self._after_tbl:
            self.spacer()

    def section(self, text: str, page_break: bool = False):
        """□ 섹션 제목: 선 없는 굵은 글자 한 줄. page_break=True면 새 쪽에서 시작."""
        self.parts.append(self._p("□ " + text, PP_SECTION, CP_H, None, page_break))
        self._after_tbl = False     # 섹션 제목은 자체 위 간격이 있어 빈 줄 불필요
        return self

    def bullet(self, text: str, level: int = 1, attach: bool | None = None, right: str | None = None):
        """level 1=○(U+25CB), 2=-, 3=·. 텍스트 안 **굵게** 지원.
        attach: 표 바로 아래일 때 빈 줄 처리. None=기본(level 2는 표에 붙임, 그 외는 빈 줄 1개),
        True=표 설명이므로 빈 줄 없이 붙임, False=빈 줄을 넣음(level 2도).
        right: 같은 줄 오른쪽 끝에 붙일 글(예 "(단위 : 백만원)"). level 1에서 글이 "(단위 …)"로 끝나면 자동으로 오른쪽 끝으로 보낸다."""
        if level == 1 and right is None:
            m = re.match(r"^(.*?)\s*(\(단위[^)]*\))\s*$", text)
            if m:
                text, right = m.group(1), m.group(2)
        glue = self._after_tbl and (attach is True or (attach is None and level == 2))
        if not glue:
            self._gap()
        attach = glue and level == 2            # '-'는 표 왼쪽 끝에 맞춘다(○·· 는 자기 위치 유지)
        mark, pp = {1: ("○ ", PP_L1), 2: ("-", PP_L2), 3: ("· ", PP_L3)}[level]
        if attach:
            pp = self._tbl_pp
        if glue and level != 2:
            self._after_tbl = False             # ○로 새 항목 묶음이 시작되면 이후는 일반 규칙
        if level == 2:   # ASCII 하이픈 '-'(U+002D)를 좁은 장평으로, 뒤 공백 1칸은 본문 글자 모양
            body = (f'<hp:run charPrIDRef="{CP_DASH}"><hp:t>-</hp:t></hp:run>'
                    + self._runs(" " + text, CP_BODY, CP_BOLD))
            self.parts.append(f'<hp:p id="{self._id()}" paraPrIDRef="{pp}" styleIDRef="0" pageBreak="0" '
                              f'columnBreak="0" merged="0">{body}</hp:p>')
        elif right and level == 1:
            body = (self._runs(mark + text, CP_BODY, CP_BOLD)
                    + f'<hp:run charPrIDRef="{CP_BODY}"><hp:t><hp:tab width="0" leader="0" type="1"/>{escape(right)}</hp:t></hp:run>')
            self.parts.append(f'<hp:p id="{self._id()}" paraPrIDRef="{PP_UNIT}" styleIDRef="0" pageBreak="0" '
                              f'columnBreak="0" merged="0">{body}</hp:p>')
        else:
            self.parts.append(self._p(mark + text, pp, CP_BODY, CP_BOLD))
        return self

    def text(self, text: str, attach: bool = False):
        """글머리 없는 본문 문단. attach=True면 표 바로 아래에 빈 줄 없이 붙인다."""
        if text.lstrip().startswith("※"):      # ※ 주석은 어디서든 작은 글자(9pt)로, 위 내용에 붙인다
            return self.note(text)
        if not (attach and self._after_tbl):
            self._gap()
        self._after_tbl = False
        self.parts.append(self._p(text, PP_TEXT, CP_BODY, CP_BOLD))
        return self

    def note(self, text: str):
        """※ 주석(9pt). 표 바로 아래에 오면 표에 붙이고 표 왼쪽 끝에 맞춘다(빈 줄 없음)."""
        self.parts.append(self._p(text, self._tbl_pp if self._after_tbl else PP_TEXT, CP_SMALL))
        return self

    def box(self, lines: list[str], width_ratio: float = 1.0, fill: bool = False):
        """요약 박스(1x1 표). 기본은 테두리만, fill=True면 옅은 회색 배경. lines는 '○ ' 항목으로 표시."""
        self._gap()
        bf = BF_BOX if fill else BF_GRID
        paras = "".join(self._p("○ " + s, PP_L1, CP_BODY, CP_BOLD) for s in lines)
        cell = self._cell(paras, 0, 0, BODY_W, 1800 * len(lines) + 600, bf, margin=(600, 600, 300, 300))
        self.parts.append(self._tbl("<hp:tr>" + cell + "</hp:tr>", 1, 1, 1800 * len(lines) + 600, bf, (600, 600, 300, 300)))
        return self

    def table(self, rows: list[list], widths: list[int] | None = None, header_rows: int = 1,
              align: list[str] | None = None, label_col: bool = False, row_h: int = 2600,
              style: str = "open", header_fill: str | None = None, total_row: bool = False,
              vlines: bool = True, pad=PAD, head_line: str = "double", indent: int = 1,
              label_cols: list[int] | None = None):
        """표.
        rows의 셀은 문자열 또는 {"t":텍스트,"cs":가로병합,"rs":세로병합,"a":"l|c|r","bold":bool}.
        - 병합으로 가려지는 칸은 rows에 쓰지 않는다(건너뛰고 다음 칸부터 채움).
        - 셀 글: "\n"으로 줄 구분. 줄이 "• "로 시작하면 작은 • 글머리(내어쓰기). **굵게** 지원.
        - widths는 열 비율(합계가 48190이 아니어도 비율대로 자동 조정). 생략하면 균등 분할.
        style: "open"(기본; 좌우 바깥선 없음, 위·아래 굵은선) | "grid"(전체 격자). 둘 다 머리글은 옅은 회색 + 아래 두 줄 선
        header_fill: 머리글 배경색. 기본 옅은 회색 #F2F2F2(없애려면 "none").
        head_line: 머리글 아래 선. "double"(두 줄, 기본) | "mid"(중간 굵기 한 줄).
        indent: 표 왼쪽 들여쓰기. 1=○ 기호 시작에 맞춤(기본), 2=- 기호 시작, 3=· 기호 시작, 0=본문 왼쪽 끝.
        label_cols: 라벨(굵게·가운데) 열 번호 목록(0부터). 예: [0, 2] → 1·3열이 항목명인 4칸 개요표. label_col=True는 [0]과 같다.
        total_row: 마지막 행을 합계 행으로(위에 중간선, 굵게). vlines: 열 사이 세로선."""
        self._gap()
        ncols = len(widths) if widths else max(sum((c.get("cs", 1) if isinstance(c, dict) else 1) for c in r) for r in rows)
        if widths is None:
            base = BODY_W // ncols
            widths = [base] * (ncols - 1) + [BODY_W - base * (ncols - 1)]
        if sum(widths) != BODY_W:       # 합계가 달라도 비율로 자동 조정(계산 실수로 표가 깨지지 않게)
            tot = sum(widths)
            widths = [max(1, round(w * BODY_W / tot)) for w in widths]
            widths[-1] += BODY_W - sum(widths)
        tbl_w, tbl_pp = BODY_W, 0
        if indent:
            tbl_w = BODY_W - TBL_INDENT[indent]
            tbl_pp = PP_TBL_IND[indent]
            widths = [round(w * tbl_w / BODY_W) for w in widths]
            widths[-1] += tbl_w - sum(widths)     # 반올림 오차는 마지막 열에서 보정
        align = align or ["c"] * ncols
        nrows = len(rows)
        HEAD = DOUBLE if head_line == "double" else MID
        if header_fill is None:
            header_fill = GRAY
        pl, pr, pt, pb = pad

        # 1단계: 셀 배치(병합 반영) + 필요한 높이 추정
        occupied: set[tuple[int, int]] = set()
        placed = []   # (r, col, cs, rs, d, lines)
        for r, row in enumerate(rows):
            col = 0
            for cell in row:
                while (r, col) in occupied:
                    col += 1
                d = cell if isinstance(cell, dict) else {"t": cell}
                cs, rs = d.get("cs", 1), d.get("rs", 1)
                assert col + cs <= ncols, f"행 {r}: 열 범위 초과"
                for rr in range(r, r + rs):
                    for cc in range(col, col + cs):
                        occupied.add((rr, cc))
                placed.append((r, col, cs, rs, d, str(d["t"]).split("\n")))
                col += cs
        row_hs = [row_h] * nrows
        for r, col, cs, rs, d, lines in placed:
            w = sum(widths[col:col + cs]) - pl - pr
            n = 0
            for ln in lines:
                bul = ln.startswith(("• ", "● "))
                avail = w - (900 if bul else 0)
                vis = len(ln.replace("**", "")) - (2 if bul else 0)
                n += max(1, -(-vis * 1050 // max(avail, 1000)))
            need = n * 1430 + pt + pb + 60
            if rs == 1:
                row_hs[r] = max(row_hs[r], need)
            elif need > sum(row_hs[r:r + rs]):
                row_hs[r + rs - 1] += need - sum(row_hs[r:r + rs])

        # 2단계: XML
        trs = [""] * nrows
        for r, col, cs, rs, d, lines in placed:
            is_head = r < header_rows
            is_label = (col in (label_cols or []) or (label_col and col == 0)) and not is_head
            is_total = total_row and r + rs - 1 == nrows - 1 and not is_head
            a = d.get("a") or ("c" if (is_head or is_label or is_total and col == 0) else align[col])
            pp = {"c": PP_CELL_C, "l": PP_CELL_LL, "r": PP_CELL_R}[a]
            bold = is_head or is_label or is_total or d.get("bold")
            cp, cpb = (CP_CELL_B, CP_CELL_B) if bold else (CP_CELL, CP_CELL_B)
            last = r + rs - 1
            if style == "grid":
                top = HEAD if r == header_rows else THIN
                bottom = HEAD if last == header_rows - 1 else THIN
                left = right = THIN
            else:
                top = THICK if r == 0 else (HEAD if r == header_rows else (MID if (total_row and r == nrows - 1) else THIN))
                bottom = THICK if last == nrows - 1 else (
                    HEAD if last == header_rows - 1 else (MID if (total_row and last == nrows - 2) else THIN))
                left = THIN if (vlines and col > 0) else None
                right = THIN if (vlines and col + cs < ncols) else None
            fill = (None if header_fill == "none" else header_fill) if is_head else (GRAY if (is_label and style == "grid") else None)
            bf = self._bf_id(left, right, top, bottom, fill)
            paras = ""
            for ln in lines:
                if ln.startswith(("• ", "● ")):
                    paras += self._p("• " + ln[2:], PP_CELLB, cp, cpb)
                else:
                    paras += self._p(ln, pp, cp, cpb)
            h = sum(row_hs[r:r + rs])
            trs[r] += self._cell(paras, col, r, sum(widths[col:col + cs]), h, bf, cs, rs, pad)
        rows_xml = "".join("<hp:tr>" + t + "</hp:tr>" for t in trs)
        self.parts.append(self._tbl(rows_xml, nrows, ncols, sum(row_hs), BF_GRID, pad, tbl_w, tbl_pp))
        self._after_tbl = True      # 다음이 ※ 주석·- 항목이면 붙이고, 그 외에는 빈 줄 자동 삽입
        self._tbl_pp = tbl_pp if indent else PP_JUSTIFY0
        return self

    def to_xml(self) -> str:
        return self.root_open + "\n" + "\n".join(self.parts) + "\n</hs:sec>\n"
