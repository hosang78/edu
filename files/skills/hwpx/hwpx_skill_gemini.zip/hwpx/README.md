# hwpx - 한글 HWPX 문서 생성·편집·검증 스킬

한컴오피스 HWPX 문서(OWPML 표준)를 AI 에이전트 환경에서 생성, 양식 보존 편집, 텍스트 추출 및 검증할 수 있는 스킬 패키지입니다.

## 주요 기능

* **새 보고서 원스톱 생성 (`make_report.py`)**: JSON 명세(`spec.json`) 하나로 보고서 HWPX 빌드, 네임스페이스 보정, 줄 배치 캐시 제거, 레이아웃 점검 및 심층 검증(`deep_check.py`)을 수행합니다.
* **원본 양식 99% 보존 편집 (`edit_hwpx.py` + `hwpx_slots.py`)**: 첨부된 HWPX 양식의 원본 ZIP 로컬 헤더와 스타일(`header.xml`), 표 구조를 그대로 유지하면서 편집 가능한 슬롯 텍스트만 안전하게 교체합니다.
* **쪽수 및 구조 드리프트 가드 (`page_guard.py`)**: 원본 양식의 문단/셀 글자 예산과 XML/ZIP 구조 fingerprint를 대조하여 레이아웃 깨짐이나 쪽수 증가를 사전에 차단합니다.
* **내용 완성도 및 공문서 표기 검수 (`content_guard.py`, `gonmun_lint.py`)**: 원문 잔재, 미치환 placeholder, 필수 키워드 누락 여부와 행정업무 운영 편람 기준 표기(날짜, 시간, 금액 등)를 검사합니다.

## 디렉토리 구조

```
hwpx/
├── SKILL.md                              # 스킬 정의 및 핵심 워크플로우 지침
├── README.md                             # 패키지 개요
├── scripts/                              # 실행 스크립트 모음
│   ├── make_report.py                    # JSON 명세 -> 보고서 HWPX 원스톱 생성
│   ├── hwpx_blocks.py                    # 제목/개조식/표/요약박스 XML 블록 빌더
│   ├── deep_check.py                     # ID 참조, itemCnt, 표 셀 배치 심층 검사
│   ├── hwpx_slots.py                     # 편집 가능 문단/셀 슬롯 JSON 추출
│   ├── edit_hwpx.py                      # 원본 ZIP 보존 + 슬롯/텍스트 최소 수정
│   ├── build_hwpx.py                     # 템플릿 + XML 조합 HWPX 조립
│   ├── analyze_template.py               # 레퍼런스 HWPX 구조 심층 분석
│   ├── validate.py                       # HWPX 구조 및 XML 유효성 검증
│   ├── fix_namespaces.py                 # 표준 네임스페이스 및 header itemCnt 보정
│   ├── finalize_hwpx.py                  # 줄 배치 캐시 제거 및 레이아웃 위험 경고
│   ├── page_guard.py                     # 글자 예산 및 구조 드리프트 검사
│   ├── content_guard.py                  # 금지어/필수어 및 원문 잔존율 검사
│   ├── gonmun_lint.py                    # 공문서 표기법 검수
│   ├── text_extract.py                   # 텍스트 추출 (plain / markdown)
│   └── office/                           # unpack.py / pack.py
├── templates/                            # 내장 템플릿 (base, gonmun, report, minutes, proposal)
├── references/                           # OWPML 포맷 및 XML 스타일 상세 레퍼런스
│   ├── hwpx-format.md
│   ├── xml-style-guide.md
│   └── jkf87-hwpx-skill-comparison.md
├── samples/                              # 샘플 JSON 명세 및 HWPX 파일
└── tests/                                # 회귀 테스트 스위트
```
