# HWPX XML 직접 작성 및 템플릿 스타일 가이드

표준 보고서 구성(제목, 개조식, 표, 요약박스)으로 해결되지 않는 특수 레이아웃이나 커스텀 템플릿 조립 시 참조하는 상세 가이드입니다.

## 1. XML-first 문서 생성 워크플로우 (build_hwpx.py)

1. 템플릿 선택 (base / gonmun / report / minutes / proposal)
2. `section0.xml` 작성 (본문 내용)
3. (선택) `header.xml` 수정 (새 스타일 추가 필요 시)
4. `build_hwpx.py`로 빌드 후 `validate.py`로 검증

```bash
# 기본 템플릿 빌드
python3 scripts/build_hwpx.py --template gonmun --output result.hwpx

# 커스텀 section0.xml 및 header.xml 오버라이드
python3 scripts/build_hwpx.py --template report --header my_header.xml --section my_section0.xml --title "제목" --creator "작성자" --output result.hwpx
```

## 2. section0.xml 필수 구조

첫 문단(`<hp:p>`)의 첫 런(`<hp:run>`)에는 반드시 `<hp:secPr>`과 `<hp:colPr>`이 포함되어야 합니다. `templates/base/Contents/section0.xml`의 첫 문단을 복사해 사용합니다.

```xml
<hp:p id="1000000001" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">
  <hp:run charPrIDRef="0">
    <hp:secPr ...>
      <!-- 페이지 크기, 여백 설정 -->
    </hp:secPr>
    <hp:ctrl>
      <hp:colPr id="" type="NEWSPAPER" layout="LEFT" colCount="1" sameSz="1" sameGap="0"/>
    </hp:ctrl>
  </hp:run>
  <hp:run charPrIDRef="0"><hp:t/></hp:run>
</hp:p>
```

### 일반 문단 및 빈 줄

```xml
<!-- 일반 문단 -->
<hp:p id="1000000002" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">
  <hp:run charPrIDRef="0"><hp:t>일반 텍스트 </hp:t></hp:run>
  <hp:run charPrIDRef="7"><hp:t>볼드 텍스트</hp:t></hp:run>
</hp:p>

<!-- 빈 줄 -->
<hp:p id="1000000003" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">
  <hp:run charPrIDRef="0"><hp:t/></hp:run>
</hp:p>
```

### 표(Table) 구조 및 크기 계산

* **A4 본문폭**: 48190 HWPUNIT = 59528(용지폭) - 5669*2(좌우여백 20mm)
* **열 너비 합계**: 반드시 본문폭(48190)과 일치해야 합니다.
* **행 높이**: 셀당 기본 2400~3600 HWPUNIT
* **셀 여백**: `hp:tc`의 `hasMargin="1"` 설정 후 `inMargin`과 `cellMargin`에 동일 값(좌우 800, 상하 220 등)을 부여합니다.

## 3. 템플릿별 스타일 ID 맵

### base (기본)

* `charPr 0`: 10pt 함초롬바탕
* `charPr 1`: 10pt 함초롬돋움
* `paraPr 0`: JUSTIFY, 160% 줄간격
* `borderFill 1~2`: 테두리 없음 / 투명 배경

### gonmun (공문)

* `charPr 7`: 22pt 볼드 함초롬바탕 (기관명/제목)
* `charPr 8`: 16pt 볼드 함초롬바탕 (서명자)
* `charPr 9`: 8pt 함초롬바탕 (하단 연락처)
* `charPr 10`: 10pt 볼드 함초롬바탕 (표 헤더)
* `paraPr 20`: CENTER, 160%
* `paraPr 21`: CENTER, 130% (표 셀)
* `paraPr 22`: JUSTIFY, 130% (표 셀)
* `borderFill 3`: SOLID 0.12mm 4면
* `borderFill 4`: SOLID 0.12mm + #D6DCE4 배경

### report (보고서) 및 hwpx_blocks 확장 스타일

* `charPr 7`: 20pt 볼드 (문서 제목)
* `charPr 8`: 14pt 볼드 (소제목)
* `charPr 9`: 10pt 볼드 (표 헤더)
* `charPr 11`: 9pt 바탕 (주석)
* `charPr 13`: 12pt 볼드 돋움 (섹션 헤더)
* `charPr 16`: 12pt 바탕 (본문)
* `charPr 17`: 12pt 볼드 바탕 (본문 강조)
* `charPr 18`: 11pt 바탕 (표 본문)
* `charPr 19`: 11pt 볼드 바탕 (표 머리글, 라벨, 합계)
* `paraPr 24~26`: 들여쓰기 left 600 / 1200 / 1800
* `paraPr 28~30`: `○`(left 600), `-`(left 1200), `·`(left 1800) 문단
* `paraPr 31`: 표 셀 오른쪽 정렬 130%
* `paraPr 34`: 표 셀 왼쪽 정렬 130%
* `paraPr 35`: 섹션 제목 (위 간격 10pt, 선 없음)

### minutes (회의록)

* `charPr 7`: 18pt 볼드 (제목)
* `charPr 8`: 12pt 볼드 (섹션 라벨)
* `charPr 9`: 10pt 볼드 (표 헤더)
* `borderFill 4`: SOLID 0.12mm + #E2EFDA 배경

### proposal (제안서/사업개요)

* `charPr 10`: 14pt 볼드 흰색 돋움 (대항목 번호, 올리브녹색 #7B8B3D `borderFill 5`)
* `charPr 11`: 11pt 볼드 흰색 돋움 (소항목 번호, 파란색 #4472C4 `borderFill 7`)
* `borderFill 6`: 연한 회색 배경 #F2F2F2 (대항목 제목 셀)
* `borderFill 8`: 하단 테두리만 #D0D0D0 (소항목 제목 영역)

## 4. 단위 변환표

| 단위 | HWPUNIT | 설명 |
|------|---------|------|
| 1pt | 100 | 기본 글자 크기 단위 (10pt = 1000) |
| 1mm | 283.5 | 밀리미터 (1cm = 2835) |
| A4 폭 | 59528 | 210mm |
| A4 높이 | 84186 | 297mm |
| 좌우여백 | 5669 | 20mm |
| 본문폭 | 48190 | 170mm (A4 폭 - 좌우여백 합) |
