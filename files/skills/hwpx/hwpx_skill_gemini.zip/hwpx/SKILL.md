---
name: hwpx
description: 한글 HWPX 문서 생성, 읽기, 편집 스킬. 한글 보고서 및 표 문서 작성, 공문서 양식 보존 편집, .hwpx 파일 텍스트 추출 및 레이아웃 검증 요청 시 사용한다. 사용자가 보고서 초안, 기획서, 회의록, 공문을 .hwpx로 요청하거나 첨부된 .hwpx 파일의 내용 수정을 요청할 때 활성화한다.
---

# HWPX 문서 스킬 (hwpx)

한글(Hancom Office)의 HWPX 파일(OWPML 표준 ZIP/XML 컨테이너)을 생성, 편집, 추출 및 검증하는 스킬입니다. 새 보고서는 JSON 명세 기반 원스톱 스크립트(`make_report.py`)로 생성하고, 첨부된 HWPX 양식 편집은 원본 ZIP 구조와 스타일 참조를 보존하는 슬롯 편집(`edit_hwpx.py`)으로 처리합니다.

## When to Use

* 첨부된 `.hwpx` 파일 없이 새 한글 보고서, 기획안, 공문, 회의록 `.hwpx` 파일 생성을 요청할 때
* 사용자가 첨부한 `.hwpx` 양식의 서식, 표 구조, 쪽수를 그대로 유지하면서 본문 텍스트나 표 셀 내용을 수정할 때
* 기존 `.hwpx` 문서에서 본문 및 표 텍스트를 평문이나 마크다운으로 추출할 때
* `.hwp` 바이너리 파일 생성이나 직접 수정을 요청할 때 (HWPX 전용 안내 후 `.hwpx`로 대체 생성 제안)

## 작업 선택 기준

| 요청 상황 | 실행 경로 |
|----------|----------|
| 첨부 HWPX 없이 새 보고서 생성 | **Step 1: 새 보고서 생성 (`make_report.py`)** |
| 첨부 HWPX 양식 유지 및 내용 변경 | **Step 2: 레퍼런스 양식 보존 편집 (`edit_hwpx.py`)** |
| 기존 HWPX 텍스트 읽기 및 추출 | **Step 3: 텍스트 추출 (`text_extract.py`)** |
| 특수 레이아웃 XML 직접 조립 | `references/xml-style-guide.md` 및 `references/hwpx-format.md` 참조 후 `build_hwpx.py` 실행 |

## Steps

### Step 1: 새 보고서 생성 (`make_report.py`)

첨부된 레퍼런스 문서가 없을 때는 XML을 수동으로 작성하지 않고 JSON 명세를 작성해 `make_report.py`로 빌드, 네임스페이스 보정, 캐시 제거, 레이아웃 검증을 한 번에 실행합니다.

1. 문서 구성을 담은 `spec.json` 파일을 작성합니다.
2. `make_report.py`와 `deep_check.py`를 순서대로 실행하여 `.hwpx` 파일을 생성하고 정합성을 검증합니다.

```bash
python3 scripts/make_report.py spec.json -o report.hwpx
python3 scripts/deep_check.py report.hwpx
```

#### JSON 명세(`spec.json`) 구조 예시

```json
{
  "title": "보고서 제목",
  "meta": "2026년 11월 2일  ICT전략팀",
  "creator": "ICT전략팀",
  "blocks": [
    {"type": "section", "text": "추진 배경", "page_break": false},
    {"type": "bullet", "text": "**핵심 항목** : 세부 추진 내용 (단위 : 백만원)", "level": 1},
    {
      "type": "table",
      "widths": [8000, 24000, 16190],
      "align": ["c", "l", "r"],
      "label_col": true,
      "rows": [
        ["구분", "주요 내용", "예산"],
        ["1단계", "• 시스템 고도화\n• 데이터 표준화", "150"]
      ]
    },
    {"type": "note", "text": "※ 상기 일정 및 예산은 추진 여건에 따라 변동 가능"}
  ]
}
```

#### 블록 타입 및 작성 규칙

* `section`: `□` 섹션 제목(선 없는 굵은 글자). 새 쪽 시작이 필요하면 `"page_break": true` 설정.
* `bullet`: `level` 1=`○`(공백 1칸 포함), 2=`-`, 3=`·`. 부분 굵게(`**텍스트**`) 지원. 문장 끝이 `(단위 ...)` 형태이거나 `"right": "(...)"` 속성을 주면 우측 끝 탭 정렬 자동 적용.
* `text` / `note`: 글머리 없는 일반 본문 / 9pt 주석(`※`).
* `box`: 테두리 요약 박스(`"lines": [...]`, `"fill": true` 설정 시 연회색 배경). 사용자가 요약 박스를 명시적으로 요청했을 때만 사용.
* `table`: 기본 `style: "open"`(좌우 바깥선 없음, 머리글 연회색 `#F2F2F2` 배경 및 하단 이중선). 병합 셀은 `{"t": "텍스트", "cs": 가로칸수, "rs": 세로칸수}`로 표기하고 가려지는 피병합 칸은 배열에서 생략. 셀 내부 줄바꿈은 `
`, 글머리는 `"• 항목"` 사용.
* **사내 표기 규칙**: 콜론 앞뒤에는 공백 1칸(`"목적 : 내용"`), 날짜는 `"2026년 11월 2일"` 형식으로 표기하고 개조식 문장은 명사형(`~함`, `~필요`, `~예정`)으로 종결.
* **표 아래 간격**: 표 직후의 `note`(`※`)와 `bullet` level 2(`-`)는 표에 자동 밀착. 표를 설명하는 `○` 항목을 빈 줄 없이 붙이려면 `"attach": true` 추가.

### Step 2: 첨부 HWPX 레퍼런스 양식 보존 편집 (`edit_hwpx.py`)

사용자가 `.hwpx` 양식을 첨부한 경우 원본의 스타일(`charPr`, `paraPr`, `borderFill`), 표 크기, 여백, 쪽수를 100% 보존하면서 슬롯 텍스트만 교체합니다.

1. **슬롯 및 예산 추출**: `hwpx_slots.py`로 편집 가능 슬롯을 추출하고, `page_guard.py`로 원본 글자 예산과 구조 프로파일을 저장합니다.
2. **슬롯 값 매핑 및 편집**: 추출된 슬롯 키(`p:12`, `cell:0:2:1` 등)에 새 텍스트를 매핑한 `values.json`을 작성하여 `edit_hwpx.py --slot-json`을 실행합니다.
3. **검증 및 가드 실행**: `validate.py`, `fix_namespaces.py`, `finalize_hwpx.py`, `page_guard.py`, `content_guard.py`를 순서대로 실행해 무결성과 쪽수 유지 여부를 확인합니다.

```bash
# 1) 슬롯 및 원본 예산/구조 프로파일 추출
python3 scripts/hwpx_slots.py reference.hwpx --output /tmp/slots.json
python3 scripts/page_guard.py --reference reference.hwpx   --write-budget /tmp/budget.json   --write-structure /tmp/structure.json

# 2) 양식 보존 슬롯 편집 (--replace, --cell, --paragraph-json 병행 가능)
python3 scripts/edit_hwpx.py reference.hwpx   --output result.hwpx   --slot-json values.json

# 3) 구조 검증, 네임스페이스 보정 및 줄 배치 캐시 제거
python3 scripts/validate.py result.hwpx
python3 scripts/fix_namespaces.py result.hwpx
python3 scripts/finalize_hwpx.py result.hwpx --strip-linesegarray --layout
python3 scripts/validate.py result.hwpx --layout

# 4) 글자 예산 및 구조 드리프트 가드 (필수)
python3 scripts/page_guard.py   --reference reference.hwpx   --output result.hwpx   --budget-profile /tmp/budget.json   --structure-profile /tmp/structure.json   --no-strict-paragraph-budget   --skip-text-drift   --allow-empty-fill

# 5) 원문 잔재 및 필수 키워드 가드 (기관/관점 전환 시 필수)
python3 scripts/content_guard.py result.hwpx --rules /tmp/content.rules.json
```

#### 양식 보존 편집 핵심 원칙

* 컨테이너 문단(표, 그림, 텍스트상자를 품은 상위 문단)은 직접 수정하지 않고 `hwpx_slots.py`가 노출한 실제 텍스트 슬롯만 수정합니다.
* 본문 재작성 시 원본 문단의 공백 제외 글자 수 이하로 작성하되, 글자 수를 맞추기 위해 띄어쓰기를 생략하거나 문장을 중간에 자르지 않습니다.
* `hp:t` 내부의 `hp:fwSpace`, `hp:lineBreak` 등 자식 컨트롤 태그는 절대 삭제하지 않습니다.
* 원본 ZIP의 로컬 헤더와 압축 데이터를 보존해야 하므로 일반 ZIP 재압축 대신 반드시 `edit_hwpx.py` 및 `finalize_hwpx.py`의 원시 ZIP 교체 방식을 사용합니다.

### Step 3: 텍스트 추출 및 공문서 표기 검수

기존 HWPX 문서의 내용을 읽거나 공문서 표기법(날짜, 시간, 금액, 붙임 등)을 점검할 때 실행합니다.

```bash
# 평문 또는 마크다운 텍스트 추출 (표 포함)
python3 scripts/text_extract.py document.hwpx --include-tables
python3 scripts/text_extract.py document.hwpx --format markdown

# 행정업무 운영 편람 기준 공문서 표기 검수
python3 scripts/gonmun_lint.py --hwpx document.hwpx --format text
```

## 스크립트 요약

* `scripts/make_report.py`: JSON 명세 기반 새 보고서 HWPX 원스톱 생성 (빌드, 검증, 최종화 통합)
* `scripts/hwpx_blocks.py`: 섹션 제목, 개조식 글머리, 병합 표, 요약 박스 XML 블록 생성 모듈
* `scripts/deep_check.py`: ID 참조, `itemCnt`, 표 셀 좌표 및 병합 정합성 심층 검사
* `scripts/hwpx_slots.py`: 첨부 HWPX에서 편집 가능한 문단 및 표 셀 슬롯 JSON 추출
* `scripts/edit_hwpx.py`: 원본 ZIP 패키지와 스타일을 보존하며 슬롯/문단/셀 텍스트만 교체
* `scripts/page_guard.py`: 원본 대비 문단/셀 글자 예산 초과 및 XML/ZIP 구조 변경 감지
* `scripts/content_guard.py`: 금지어(원문 잔재, placeholder) 및 필수 키워드 누락 검사
* `scripts/finalize_hwpx.py`: `hp:linesegarray` 줄 배치 캐시 제거 및 표 밀도/들여쓰기 경고
* `scripts/fix_namespaces.py`: 표준 OWPML 네임스페이스 프리픽스 및 `header.xml` `itemCnt` 보정
* `scripts/validate.py`: HWPX ZIP 구조, `mimetype` 위치/압축방식, XML 문법 유효성 검증
* `scripts/analyze_template.py`: 레퍼런스 HWPX의 스타일, 여백, 표 구조 심층 분석 및 XML 추출
* `scripts/build_hwpx.py`: 템플릿(`base`, `gonmun`, `report`, `minutes`, `proposal`)과 XML을 조합해 HWPX 생성
* `scripts/text_extract.py`: HWPX 본문 및 표 텍스트 추출 (plain / markdown)
* `scripts/gonmun_lint.py`: 공문서 날짜, 시간, 금액, 붙임 표기 오류 검사

## Gotchas

* **HWP 바이너리 직접 생성 불가**: `.hwp` 바이너리 파일은 직접 생성하거나 수정할 수 없습니다. 사용자가 `.hwp`를 요청하면 HWPX 전용임을 안내하고, 한글에서 `.hwpx`로 저장해 제공하거나 결과물을 `.hwpx`로 받을 수 있는지 확인하세요.
* **Python 실행 주의**: 스크립트 실행 시 `python3 -I`(격리 모드)를 사용하면 동일 폴더의 모듈 import가 실패하므로 일반 `python3`로 실행합니다.
* **unpack `--pretty` 재패키징 금지**: `scripts/office/unpack.py --pretty`는 사람이 XML을 읽기 위한 검사 전용입니다. 들여쓰기 공백이 실제 텍스트로 렌더링될 수 있으므로 `--pretty`로 푼 폴더를 다시 `pack.py`로 묶지 마세요.
* **한글 열림 확인 안내**: 구조 검증기를 통과하더라도 뷰어 환경에 따라 렌더링 차이가 있을 수 있으므로, 결과 파일 전달 시 한글 오피스에서 열어 레이아웃을 확인하도록 안내하세요.
