#!/usr/bin/env python3
"""hwpx_blocks / make_report / deep_check 회귀 테스트. 실행: python3 -m unittest test_blocks"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import deep_check  # noqa: E402
from hwpx_blocks import BODY_W, Doc, patched_header  # noqa: E402

SAMPLE = ROOT / "samples" / "sample_report.json"
SAMPLE2 = ROOT / "samples" / "sample_complex.json"


class BlockTests(unittest.TestCase):
    def test_patched_header_counts_and_ids(self) -> None:
        h = patched_header()
        self.assertIn('<hh:paraProperties itemCnt="40"', h)
        self.assertIn('<hh:borderFills itemCnt="9"', h)
        self.assertIn('<hh:charProperties itemCnt="22"', h)

    def test_table_scales_widths_to_body(self) -> None:
        d = Doc()
        d.table([["a", "b"]], widths=[100, 200], indent=0)
        self.assertIn(f'width="{BODY_W}"', d.to_xml())

    def test_table_rowspan_colspan_grid(self) -> None:
        d = Doc()
        d.table([[{"t": "구분", "rs": 2}, {"t": "합", "cs": 2}], ["x", "y"], ["a", "b", "c"]],
                widths=[10000, 16000, 16520], header_rows=2)
        xml = d.to_xml()
        self.assertEqual(xml.count("<hp:tc "), 7)  # 2 + 2 + 3 (가려진 칸 제외)

    def test_table_height_follows_wrapping_and_keeps_explicit_minimum(self) -> None:
        d = Doc()
        rows = [["A", "123,456"], ["글" * 27, "123,456"]]
        d.table(rows, widths=[10000, 38190], indent=0)
        d.table(rows, widths=[10000, 38190], indent=0, row_h=2700)
        root = etree.fromstring(d.to_xml().encode())
        heights = []
        for table in root.findall(".//hp:tbl", deep_check.NS):
            heights.append([
                int(row.find("hp:tc/hp:cellSz", deep_check.NS).get("height"))
                for row in table.findall("hp:tr", deep_check.NS)
            ])
            self.assertEqual(deep_check._check_generated_table(table, "sample"), [])
        self.assertLess(heights[0][0], 2600)
        self.assertGreater(heights[0][1], heights[0][0])
        self.assertEqual(heights[1][0], 2700)

    def test_generated_table_guard_flags_layout_and_protection(self) -> None:
        d = Doc()
        d.table([[{"t": "입력값", "form_editable": True}, "일반 셀"]])
        root = etree.fromstring(d.to_xml().encode())
        table = root.find(".//hp:tbl", deep_check.NS)
        cells = table.findall("hp:tr/hp:tc", deep_check.NS)
        self.assertEqual([cell.get("editable") for cell in cells], ["1", "0"])
        self.assertEqual(deep_check._check_generated_table(table, "sample"), [])
        table.find("hp:pos", deep_check.NS).set("affectLSpacing", "1")
        cells[0].set("protect", "1")
        cells[1].find("hp:cellSz", deep_check.NS).set("height", "9000")
        errors = deep_check._check_generated_table(table, "sample")
        self.assertEqual(len(errors), 3)
        self.assertTrue(any("줄 간격" in e for e in errors))
        self.assertTrue(any("셀 보호" in e for e in errors))
        self.assertTrue(any("높이 불일치" in e for e in errors))

    def test_end_to_end_samples_pass_deep_check(self) -> None:
        for sample in (SAMPLE, SAMPLE2):
            with tempfile.TemporaryDirectory() as td:
                out = Path(td) / "s.hwpx"
                r = subprocess.run([sys.executable, str(ROOT / "scripts" / "make_report.py"), str(sample), "-o", str(out)],
                                   capture_output=True, text=True)
                self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
                self.assertEqual(deep_check.check(str(out)), [])


if __name__ == "__main__":
    unittest.main()
