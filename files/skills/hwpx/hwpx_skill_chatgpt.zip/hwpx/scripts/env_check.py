#!/usr/bin/env python3
"""hwpx 스킬 실행 환경 점검 (Claude / ChatGPT 공용).

사용:
  python3 env_check.py

확인 항목
- Python 버전
- lxml 설치 여부 (유일한 외부 의존성)
- 스킬 폴더 구성 (scripts/, templates/)과 스킬 폴더 쓰기 가능 여부
- 결과 파일을 둘 만한 쓰기 가능 폴더 후보

종료 코드: 0 = 바로 사용 가능, 1 = 조치 필요
"""
import os
import sys
import tempfile
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent

REQUIRED = [
    "scripts/make_report.py",
    "scripts/hwpx_blocks.py",
    "scripts/deep_check.py",
    "scripts/validate.py",
    "scripts/edit_hwpx.py",
    "templates/base/Contents/header.xml",
    "templates/report/header.xml",
]

OUTPUT_CANDIDATES = [
    "/mnt/data",          # ChatGPT 코드 실행 샌드박스
    "/mnt/user-data/outputs",  # Claude 샌드박스
    "/mnt/outputs",
]


def writable(path):
    try:
        with tempfile.TemporaryFile(dir=str(path)):
            return True
    except OSError:
        return False


def main():
    ok = True
    print(f"SKILL_DIR      : {SKILL_DIR}")

    v = sys.version_info
    print(f"Python         : {v.major}.{v.minor}.{v.micro}", end="")
    if v < (3, 6):
        print("  [부족: 3.6 이상 필요]")
        ok = False
    else:
        print("  [OK]")

    try:
        import lxml  # noqa: F401
        from lxml import etree
        print(f"lxml           : {'.'.join(map(str, etree.LXML_VERSION))}  [OK]")
    except ImportError:
        print("lxml           : 없음  [조치 필요]")
        print("  → pip install lxml  (Claude 샌드박스는 --break-system-packages 추가)")
        print("  → 네트워크가 막혀 설치할 수 없으면 사용자에게 환경 제한을 알릴 것")
        ok = False

    missing = [p for p in REQUIRED if not (SKILL_DIR / p).exists()]
    if missing:
        print("스킬 폴더 구성 : 누락 파일 있음  [조치 필요]")
        for p in missing:
            print(f"  - {p}")
        ok = False
    else:
        print("스킬 폴더 구성 : scripts/ templates/ 확인  [OK]")

    if writable(SKILL_DIR):
        print("스킬 폴더 쓰기 : 가능 (그래도 작업 파일은 별도 작업 폴더에 둘 것)")
    else:
        print("스킬 폴더 쓰기 : 읽기 전용 (정상 — 작업 파일은 작업/임시 폴더에 둘 것)")

    cwd = Path.cwd()
    outs = [Path(p) for p in OUTPUT_CANDIDATES if Path(p).is_dir() and writable(Path(p))]
    print(f"현재 작업 폴더 : {cwd}  ({'쓰기 가능' if writable(cwd) else '쓰기 불가'})")
    if outs:
        print("출력 폴더 후보 : " + ", ".join(str(p) for p in outs))
    else:
        print("출력 폴더 후보 : 알려진 위치 없음 → 작업 폴더에 저장 후 파일 전달 도구/링크 사용")
    print(f"임시 폴더      : {tempfile.gettempdir()}")

    print()
    print("결과: " + ("바로 사용 가능" if ok else "위 [조치 필요] 항목 해결 후 진행"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
