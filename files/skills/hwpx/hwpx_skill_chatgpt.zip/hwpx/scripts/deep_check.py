#!/usr/bin/env python3
"""HWPX 심층 정합성 검사 (validate.py가 놓치는 항목).

검사 항목
- header.xml 그룹별 itemCnt == 실제 자식 수, ID 중복 없음
- section의 charPrIDRef / paraPrIDRef / borderFillIDRef가 header에 존재
- 문단 id, 표 id 전역 중복 없음
- 표: rowCnt/colCnt와 실제 셀 배치(병합 포함)가 빈틈·겹침 없이 일치, 행별 셀 너비 합 == 표 너비
- 쪽 나눔 수(pageBreak="1") 보고(예상 최소 쪽수)

--generated-tables: 새로 생성한 문서의 표 잠금·줄 간격과 행/표 높이 합도 검사

사용: python3 deep_check.py file.hwpx [--generated-tables]   (실패 시 종료코드 1)
"""
from __future__ import annotations

import argparse
import re
import zipfile
from collections import Counter

from lxml import etree

HP = "http://www.hancom.co.kr/hwpml/2011/paragraph"
HH = "http://www.hancom.co.kr/hwpml/2011/head"
NS = {"hp": HP, "hh": HH}


def _check_generated_table(table, name: str) -> list[str]:
    errors = []
    label = f"{name}: 표(id={table.get('id')})"
    size = table.find("hp:sz", NS)
    position = table.find("hp:pos", NS)
    if table.get("lock") != "0" or size.get("protect") != "0":
        errors.append(f"{label} 개체 잠금 또는 크기 보호 설정")
    if position is None or (position.get("treatAsChar"), position.get("affectLSpacing")) != ("1", "0"):
        errors.append(f"{label} 표를 글자처럼 배치하고 문단 줄 간격에는 반영하지 않도록 설정해야 합니다.")

    row_count = int(table.get("rowCnt"))
    row_heights: dict[int, int] = {0: 0, row_count: int(size.get("height"))}
    spans = []
    # Cell heights define distances between row boundaries, including merged rows.
    for cell in table.findall("hp:tr/hp:tc", NS):
        if cell.get("protect") != "0":
            errors.append(f"{label} 셀 보호가 설정되었습니다.")
        addr, span, cell_size = (cell.find(f"hp:{k}", NS) for k in ("cellAddr", "cellSpan", "cellSz"))
        start = int(addr.get("rowAddr"))
        end = start + int(span.get("rowSpan"))
        height = int(cell_size.get("height"))
        if height <= 0 or not 0 <= start < end <= row_count:
            errors.append(f"{label} 잘못된 셀 높이 또는 행 범위")
        spans.append((start, end, height))

    pending = spans
    while pending:
        remaining = []
        for start, end, height in pending:
            if start in row_heights and end in row_heights:
                if row_heights[end] - row_heights[start] != height:
                    errors.append(f"{label} {start + 1}행 셀과 표 높이 불일치")
            elif start in row_heights:
                row_heights[end] = row_heights[start] + height
            elif end in row_heights:
                row_heights[start] = row_heights[end] - height
            else:
                remaining.append((start, end, height))
        if len(remaining) == len(pending):
            # A fully merged interior can have no boundary connected to the outer rows.
            start, _, _ = remaining[0]
            row_heights[start] = 0
        pending = remaining
    return errors


def check(path: str, *, generated_tables: bool = False) -> list[str]:
    errs: list[str] = []
    z = zipfile.ZipFile(path)
    hdr = etree.fromstring(z.read("Contents/header.xml"))
    secs = [n for n in z.namelist() if re.fullmatch(r"Contents/section\d+\.xml", n)]

    ids: dict[str, set[str]] = {}
    for group, item in (("charProperties", "charPr"), ("paraProperties", "paraPr"),
                        ("borderFills", "borderFill"), ("numberings", "numbering"), ("styles", "style")):
        g = hdr.find(f".//hh:{group}", NS)
        if g is None:
            continue
        kids = g.findall(f"hh:{item}", NS)
        if int(g.get("itemCnt", -1)) != len(kids):
            errs.append(f"{group}: itemCnt={g.get('itemCnt')} 실제={len(kids)}")
        got = [k.get("id") for k in kids]
        dup = [i for i, c in Counter(got).items() if c > 1]
        if dup:
            errs.append(f"{group}: ID 중복 {dup}")
        ids[item] = set(got)

    pids: list[str] = []
    tids: list[str] = []
    breaks = 0
    for name in secs:
        sec = etree.fromstring(z.read(name))
        for el in sec.iter():
            for attr, kind in (("charPrIDRef", "charPr"), ("paraPrIDRef", "paraPr"), ("borderFillIDRef", "borderFill")):
                v = el.get(attr)
                if v is not None and kind in ids and v not in ids[kind]:
                    errs.append(f"{name}: {el.tag.split('}')[1]} {attr}={v} 가 header에 없음")
        for p in sec.iter(f"{{{HP}}}p"):
            pids.append(p.get("id"))
            if p.get("pageBreak") == "1":
                breaks += 1
        for tbl in sec.iter(f"{{{HP}}}tbl"):
            tids.append(tbl.get("id"))
            if generated_tables:
                errs.extend(_check_generated_table(tbl, name))
            rows, cols = int(tbl.get("rowCnt")), int(tbl.get("colCnt"))
            tw = int(tbl.find("hp:sz", NS).get("width"))
            grid: dict[tuple[int, int], int] = {}
            rowsum: dict[int, int] = {}
            for tc in tbl.iter(f"{{{HP}}}tc"):
                a = tc.find("hp:cellAddr", NS)
                s = tc.find("hp:cellSpan", NS)
                z_ = tc.find("hp:cellSz", NS)
                c0, r0 = int(a.get("colAddr")), int(a.get("rowAddr"))
                cs, rs = int(s.get("colSpan")), int(s.get("rowSpan"))
                w = int(z_.get("width"))
                rowsum[r0] = rowsum.get(r0, 0) + w
                for r in range(r0, r0 + rs):
                    for c in range(c0, c0 + cs):
                        grid[(r, c)] = grid.get((r, c), 0) + 1
            holes = [(r, c) for r in range(rows) for c in range(cols) if (r, c) not in grid]
            overl = [k for k, v in grid.items() if v > 1]
            outside = [k for k in grid if k[0] >= rows or k[1] >= cols]
            if holes or overl or outside:
                errs.append(f"{name}: 표(id={tbl.get('id')}) 셀 배치 불일치 빈칸={holes[:3]} 겹침={overl[:3]} 범위밖={outside[:3]}")
            # 세로 병합으로 가려진 칸이 있는 행은 합계가 작을 수 있어 첫 행만 엄격 검사
            if rowsum.get(0, tw) != tw:
                errs.append(f"{name}: 표(id={tbl.get('id')}) 첫 행 셀 너비 합 {rowsum.get(0)} != 표 너비 {tw}")
    for label, lst in (("문단 id", pids), ("표 id", tids)):
        dup = [i for i, c in Counter(lst).items() if c > 1 and i is not None]
        if dup:
            errs.append(f"{label} 중복: {dup[:5]}")
    print(f"문단 {len(pids)}개, 표 {len(tids)}개, 쪽 나눔 {breaks}회 → 최소 {breaks + 1}쪽")
    return errs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file")
    parser.add_argument("--generated-tables", action="store_true")
    args = parser.parse_args()
    e = check(args.file, generated_tables=args.generated_tables)
    if e:
        print("DEEP CHECK FAIL")
        for x in e:
            print(" -", x)
        raise SystemExit(1)
    print("DEEP CHECK PASS")
